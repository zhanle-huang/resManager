//数据
var res_post =  {   //假数据，帖子
				postId : 1,
				title : '路见不平一脚踹',
				name : 3117004268,
				content: '内阿萨大四很多撒谎大时代i按时爱上帝阿三华硕i安徽打开撒大苏打还是金卡和爱神的箭按实际宽度和啊吉萨客户端尽快暗黑世界肯定会就爱看圣诞节卡号就肯定会阿贾克斯阿瑟东阿瑟东阿瑟东',
				postDate : '2019-11-02',
				quality : '0'
			}
//假数据,评论
var comment = [
	{
		commentId : 1,
		postId : 1,
		studentId : 6654,
		content : 'sadsafa',
		time : '2019-01-01 12:12:00',
		children : ''
	},
	{
		commentId : 2,
		postId : 1,
		studentId : 3469,
		content : 'dasfaasd',
		time : '2019-01-01 12:25:00',
		children : ''
	}
]
var replys1 = [
	{
		commentId : 1,
		replyId : 1,
		studentId : 3114,
		content : 'sadasd//@311700:哈哈哈',
		time : '2019-02-022 12:12:12'
	},
	{
		commentId : 1,
		replyId : 2,
		studentId : 3134,
		content : 'asdsadasda//@311700:hehehe',
		time : '2019-02-022 12:12:16'
	}
]
var replys2 = [
	{
		commentId : 2,
		replyId : 3,
		studentId : 4654,
		content : 'sadasd//@311700:噜噜噜',
		time : '2019-02-022 12:12:12'
	},
	{
		commentId : 2,
		replyId : 4,
		studentId : 365,
		content : 'asdsadasda//@311700:咕咕咕',
		time : '2019-02-022 12:12:16'
	}
]
comment[0].children = replys1
comment[1].children = replys2

//获取元素
var comment_ul = $('.comment ul');
//评论id
var post = $('.container .postId').text()
var container = $('.container')
var p_head = $('.container .p_header')
var p_author = $('.container .author_info')
var content = $('.container .content')
var post = $('.container .postId').text()
//评论id


//方法
//帖子渲染
function makePost(res_post){
	container[0].getElementsByTagName('h3')[0].innerText = res_post.title
	
	container[0].getElementsByClassName('postId')[0].innerText = res_post.postId
	p_author[0].getElementsByClassName('author')[0].innerText = res_post.name
	p_author[0].getElementsByClassName('time')[0].innerText = res_post.postDate
	content[0].innerText = res_post.content
}
//评论
function getComments(ul, res){
	var comments = ''
	var replys = ''
	for(var i = 0; i<res.length; i++){   //遍历评论
		comments += '<li>\
			<p><span class="glyphicon glyphicon-user"></span><span class="id">' + res[i].studentId + ':</span><span class="commentId">' + res[i].commentId + '</span></p>\
			<p class="c_content">' + res[i].content + '</p>\
			<p class="c_del"><span class="time">' + res[i].time + '</span><span class="btn btn-del">删除</span></p>'
		for(var j = 0; j<res[i].children.length; j++){  //遍历子数据
			replys += '<li>\
				<p><span class="glyphicon glyphicon-user"></span><span class="id">' + res[i].children[j].studentId + ':</span><span class="commentId">' + res[i].children[j].commentId + '</span></p>\
				<p class="c_content">' + res[i].children[j].content + '</p>\
				<p class="reply"><span class="time">' + res[i].children[j].time + '</span>\
			</li>'
		}
		if(replys != '' && replys != null){   //拼接子节点
			replys = '<ol>' + replys + '</ol></li>'
			comments += replys
			replys = ''
		}
		else{
			comments += '</li>'
		}
	}
	ul.html(comments)
}

//事件
$('.container .p_del span.btn-del').on('click', function(){
	var id = container[0].getElementsByClassName('postId')[0].innerText
	console.log(id)
	ajax('get', '/resource/delPost',{
			postId : id
		}, del_callback)
})
//删除评论事件
comment_ul.on('click', function(e){
	if(e.target.classList.contains('btn-del')){
		var e_li = e.target.parentNode.parentNode
		var id = container[0].getElementsByClassName('postId')[0].innerText
		var p_id = e_li.getElementsByClassName('commentId')[0].innerText
		console.log(p_id)
		ajax('get', '/resource/delComment',{
			postId : id,
			commentId : p_id
		}, callback)
		init()
	}
})


function post_callback(xhr){
	var res = xhr.responseText
	res = rextojson(res)
	res = JSON.parse(res)
	if(res.status === 200){
		makePost(res.data)
	} else {
		alert(res.msg)
	}
}
function comment_callback(xhr){
	var res = xhr.responseText
	console.log(res)
	res = rextojson(res)
	console.log(res)
	res = JSON.parse(res)
	if(res.status === 200){
		getComments(comment_ul, res.data)
		var main = $(window.parent.document).find("#managerIframe");
		var thisheight = $(document).height();
		main.height(thisheight);
	} else {
		alert(res.msg)
	}
}
function init(){
	var id = location.search.substring(1)
	ajax('get', '/resource/getPost',{
		postId : id
	}, post_callback)
	ajax('get', '/resource/getComments',{
		postId : id
	}, comment_callback)
}
//调用
$(function(){
	init()
})
function del_callback(xhr){
	var res = xhr.responseText
	res = JSON.parse(res)
	if(res.status === 200){
		alert(res.msg)
		location.href = 'managerPost.html'
	} else {
		alert(res.msg)
	}
}
function callback(xhr){
	var res = xhr.responseText
	res = JSON.parse(res)
	if(res.status === 200){
		alert(res.msg)
	} else {
		alert(res.msg)
	}
}