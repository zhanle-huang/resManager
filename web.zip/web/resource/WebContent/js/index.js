/*动态列表*/
var con_list = document.querySelector("#fr_info .list");
var list_ol = document.querySelector("#fr_info .list ol");
var list_li = list_ol.getElementsByTagName("li")[0];
console.log(con_list,list_ol,list_li,"ss")
function scrollLi(con, o, oChild){
	var oHeight = o.offsetHeight;//得到对象高度
	var oChildHeight = oChild.offsetHeight; //每个li的高度
	var contentHeight = con.offsetHeight; //容器的高度
	isHoverList = false;  //鼠标悬停列表标志
	liTimer = setInterval(function(){
		if(isHoverList){
			return;
		}
		if(o.offsetTop <= contentHeight - oHeight ){
			console.log("1q1");
			o.style.top = 0 - oChildHeight + "px";
		}
		else{
			// o.style.top = o.offsetTop - oChildHeight + "px";
			dHMove(o, .6, 0, o.offsetTop-oChildHeight, 0);
		}
		
	}, 1500);
}
scrollLi(con_list, list_ol, list_li);
//动态列表悬停鼠标事件
con_list.addEventListener("mouseenter", function(){
	isHoverList = true;
}, false)
con_list.addEventListener("mouseleave", function(){
	isHoverList = false;
}, false)
//获取动态列表数据
var lists = [{
	postId : 1,
	title : '业务知识',
	content : '的撒大和是打电话爱睡觉的哈桑记得哈时',
	name : '3117004268',
	postDate : '2019-11-30 11:12:20'
},{
	postId : 2,
	title : '交流知识',
	content : '的撒打电话爱睡觉的哈桑记得哈时',
	name : '3117003338',
	postDate : '2019-11-30 11:12:20'
},{
	postId : 3,
	title : '333',
	content : '的撒大和是打电话爱睡觉的哈桑记得哈时',
	name : '3117004268',
	postDate : '2019-11-30 11:12:20'
},{
	postId : 4,
	title : '444',
	content : '的撒大和是打电话爱睡觉的哈桑记得哈时',
	name : '3117004268',
	postDate : '2019-11-30 11:12:20'
},{
	postId : 5,
	title : '555',
	content : '的撒大和是打电话爱睡觉的哈桑记得哈时',
	name : '3117004268',
	postDate : '2019-11-30 11:12:20'
},{
	postId : 6,
	title : '6666',
	content : '的撒大和是打电话爱睡觉的哈桑记得哈时',
	name : '3117004268',
	postDate : '2019-11-30 11:12:20'
},{
	postId : 7,
	title : '7777',
	content : '的撒大和是打电话爱睡觉的哈桑记得哈时',
	name : '3117004268',
	postDate : '2019-11-30 11:12:20'
},{
	postId : 8,
	title : '8888',
	content : '的撒大和是打电话爱睡觉的哈桑记得哈时',
	name : '3117004268',
	postDate : '2019-11-30 11:12:20'
},{
	postId : 9,
	title : '9999',
	content : '的撒大和是打电话爱睡觉的哈桑记得哈时',
	name : '3117004268',
	postDate : '2019-11-30 11:12:20'
},{
	postId : 10,
	title : '1010',
	content : '的撒大和是打电话爱睡觉的哈桑记得哈时',
	name : '3117004268',
	postDate : '2019-11-30 11:12:20'
}]
function getListData(res){
	var res_list = ''
	for(var i = 0; i<res.length; i++){
		res_list += '<li><a href="post.html?' + res[i].postId + '" target="_blank">' + res[i].title + '</a></li>'
	}
	if(res_list != '' && res_list != null){
		var ol_height = 25*res.length;
		list_ol.style.height = ol_height + 'px'
		res_list += res_list
		list_ol.innerHTML = res_list	
	}
}

//获取帖子数据
var res = [{
	postId : 1,
	title : '业务知识',
	content : '的撒大和是打电话爱睡觉的哈桑记得哈时',
	name : '3117004268',
	postDate : '2019-11-30 11:12:20'
},{
	postId : 2,
	title : '交流知识',
	content : '的撒打电话爱睡觉的哈桑记得哈时',
	name : '3117003338',
	postDate : '2019-11-30 11:12:20'
}]
var rec_ul = document.querySelector(".recommend .panel .panel-body ul")
var hot_ul = document.querySelector(".hot .panel .panel-body ul")

function getPost(e_ul, res, src){
	console.log(src)
	var res_lis = '';
	for(var i = 0; i<res.length; i++){ 
		res_lis += '<li class="col-md-10 col-md-offset-1">\
			<img src="'+src+'" width="30" height="30"><h3>' + res[i].title + '</h3><span class="postId">' + res[i].postId + '</span>\
			<p class="content">' + res[i].content + '</p>\
			<p class="belong_info"><span class="author"><span class="glyphicon glyphicon-user"></span>' + res[i].name + '</span>\
				<span class="info">\
					<span class="glyphicon glyphicon-heart-empty">2019</span>\
					<span class="glyphicon glyphicon-eye-open">2350</span>\
					<span class="glyphicon glyphicon-comment">1563</span>\
				</span>\
			</p>\
		</li>'
	}
	if(res_lis != '' && res_lis != null){
		e_ul.innerHTML = res_lis;
	}
	
}


function getData(){
	ajax('get', '/resource/getPosts',{
		pageSize : '13',
		pageNum : '1', 
	}, list_callback)
	ajax('get', '/resource/getPosts',{
		pageSize : '10',
		pageNum : '1', 
	}, recommend_callback)
	ajax('get', '/resource/getPosts',{
		pageSize : '10',
		pageNum : '1', 
	}, hot_callback)
}
function list_callback(xhr){
	var res = xhr.responseText
	if(StringtoJson(res)){
		res = StringtoJson(res)
	}
	res = JSON.parse(res)
	
	if(res.status === 200){
		getListData(res.data)
	} else {
		alert(res.msg)
	}
}

function recommend_callback(xhr){
	var res = xhr.responseText
	if(StringtoJson(res)){
		res = StringtoJson(res)
	}
	res = JSON.parse(res)
	if(res.status === 200){
		getPost(rec_ul, res.data, '../images/recommend.svg')
	} else {
		alert(res.msg)
	}
}
function hot_callback(xhr){
	var res = xhr.responseText
	if(StringtoJson(res)){
		res = StringtoJson(res)
	}
	console.log(res)
	res = JSON.parse(res)
	
	if(res.status === 200){
		getPost(hot_ul, res.data, '../images/hot.svg')
	} else {
		alert(res.msg)
	}
}
function isLogin(){
	var token = window.sessionStorage.getItem('token')
	if(token){
		$('.topnav .navbar-right .login').css('display', 'none')
		$('.topnav .navbar-right .userName').css('display', 'inline-block')
		$('.topnav .navbar-right .userName')[0].getElementsByTagName('a')[0].innerText = window.sessionStorage.getItem('studentId')
		if(window.sessionStorage.getItem('identity') == 2){
			$('.topnav .navbar-nav .manager').css('display', 'inline-block')
		}
	} else {
		$('.topnav .navbar-right .login').css('display', 'inline-block')
		$('.topnav .navbar-right .userName').css('display', 'none')
	}
	
}

//获取帖子id
$('.fr_text .panel .panel-body ul').on('click', function(e){
	if(e.target.nodeName.toUpperCase() === 'H3'){
		var el_li = e.target.parentNode
		var id = el_li.getElementsByClassName('postId')[0].innerText  //得到被点击的帖子id
		location.href = 'post.html?' + id
	}
})
$('.topnav .navbar-right .eixt').on('click', function(){
	window.sessionStorage.removeItem('token')
	isLogin()
})

$(function(){
	isLogin()
	getData()
})