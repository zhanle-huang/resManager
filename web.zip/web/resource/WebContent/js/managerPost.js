//数据
var data_page = {   //data变量用于
	pageNum : '1',
	pageSize  : '6',
	total : ''
}


//获取元素
var el_ul = $('.container .panel ul')

//方法
function makePostList(obj, res, src){
	var res_lis = '';
	for(var i = 0; i<res.length; i++){ 
		res_lis += '<li class="col-md-10 col-md-offset-1">\
			<img src="'+src+'" width="30" height="30"><h3>' + res[i].title + '</h3><span class="postId">' + res[i].postId + '</span>\
			<p class="content">' + res[i].content + '</p>\
			<p class="belong_info"><span class="author"><span class="glyphicon glyphicon-user"></span>' + res[i].name + '</span>\
				<span class="info">\
					<span class="glyphicon glyphicon-heart-empty">2019</span>\
					<span class="glyphicon glyphicon-eye-open">2350</span>\
					<span class="glyphicon glyphicon-comment">1563</span>\
				</span>\
			</p>\
			<span class="btn btn-danger btn-sm btn-del">删除</span>\
		</li>'
	}
	if(res_lis != '' && res_lis != null){
		obj.innerHTML = res_lis
		var main = $(window.parent.document).find("#managerIframe");
		var thisheight = $(document).height();
		main.height(thisheight);
	}
	
}

//事件
$('.container .panel .panel-body ul').on('click', function(e){
	if(e.target.nodeName.toUpperCase() === 'H3'){
		var el_li = e.target.parentNode
		var id = el_li.getElementsByClassName('postId')[0].innerText  //得到被点击的帖子id
		location.href = 'managerComment.html?' + id
	} else if(e.target.classList.contains('btn-del')){
		var el_li = e.target.parentNode
		var id = el_li.getElementsByClassName('postId')[0].innerText
		ajax('get', '/resource/delPost',{
			postId : id
		}, del_callback)
		ajax('get', '/resource/getPosts',data_page, post_callback)
	}
})
//ul鼠标悬浮和离开事件
$('.container .panel .panel-body ul').on('mouseenter', function(e){
	$('.container .panel ul li span.btn-del').css('display', 'inline-block')
})
$('.container .panel .panel-body ul').on('mouseleave', function(e){
	$('.container .panel ul li span.btn-del').css('display', 'none')
})
$(function(){
	
	ajax('get', '/resource/getPosts',data_page, post_callback)
	var main = $(window.parent.document).find("#managerIframe");
	var thisheight = $(document).height();
	main.height(thisheight);
})
//回调
function post_callback(xhr){
	var res = xhr.responseText
	if(StringtoJson(res)){
		res = StringtoJson(res)
	}
	res = JSON.parse(res)
	if(res.status === 200){
		data_page.total = res.total
		startPage(data_page, page_callback)
		makePostList(el_ul[0], res.data, '../images/recommend.svg')
		
	} else {
		alert(res.msg)
	}
}
function del_callback(xhr){
	var res = xhr.responseText
	res = JSON.parse(res)
	if(res.status === 200){
		alert(res.msg)
	} else {
		alert(res.msg)
	}
}
function page_callback(){
	ajax('get', '/resource/getPosts',data_page, post_callback)
}
//调用

