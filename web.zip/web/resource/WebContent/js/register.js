$(function(){
	console.log($('form').serialize())
})

//数据
var data1 = {}

//方法
function re_callback(xhr){
	var res = xhr.responseText
	if(StringtoJson2(res)){
		res = StringtoJson2(res)
	}
	res = JSON.parse(res)
	if(res.status === 200){
		alert('注册成功!')
		location.href = 'login.html'
	} else {
		alert('注册失败！')
	}
	
}



//事件
//注册事件
$('#register').on('click', function(){
	var str = $('form').serialize()
	console.log(str)
	ajax('post', '/resource/register',  str, re_callback)
})
//调用
