//数据
var res_data = {
	resourceId : 1,
	uploader : 4564,
	name : '爬虫',
	descn : '通用爬虫和聚焦爬虫根据使用场景，网络爬虫可分为 通用爬虫 和 聚焦爬虫 两种.通用爬虫通用网络爬虫 是引擎抓取系统（Baidu、Google、Yahoo等）的重要组成部分。主要目的是将互联网上的网页下载到本地，形成一个互联网内容的镜像备份通用搜索引擎（Search Engine）工作原理通用网络爬虫 从互联网中搜集网页，采集信息，这些网页信息用于为搜索引建立索引从而提供支持，它决定着整个引擎系统的内容是否丰富，信息是否即时，因此其性能的优劣直接影响着搜索引擎的效果。第一步：抓取网页搜索引擎网络爬虫的基本工作流程如下：首先选取一部分的种子URL，将这些URL放入待抓取URL队列；取出待抓取URL，解析DNS得到主机的IP，并将URL对应的网页下载下来，存储进已下载网页库中，并且将这些URL放进已抓取URL队列。分析已抓取URL队列中的URL，分析其中的其他URL，并且将URL放入待抓取URL队列，从而进入下一个循环....搜索引擎如何获取一个网站的URL：1. 新网站向搜索引擎主动提交网址：（如百度http://zhanzhang.baidu.com/linksubmit/url）2. 在其他网站上设置新网站外链（尽可能处于搜索引擎爬虫爬取范围）3. 搜索引擎和DNS解析服务商(如DNSPod等）合作，新网站域名将被迅速抓取。但是搜索引擎蜘蛛的爬行是被输入了一定的规则的，它需要遵从一些命令或文件的内容，如标注为nofollow的链接，或者是Rbots协议。Robots协议（也叫爬虫协议、机器人协议等），全称是“网络爬虫排除标准”（Robots Exclusion Protocol），网站通过Robots协议告诉搜索引擎哪些页面可以抓取，哪些页面不能抓取，例如：淘宝网：https://www.taobao.com/robots.txt腾讯网： http://www.qq.com/robots.txt第二步：数据存储搜索引擎通过爬虫爬取到的网页，将数据存入原始页面数据库。其中的页面数据与用户浏览器得到的HTML是完全一样的。搜索引擎蜘蛛在抓取页面时，也做一定的重复内容检测，一旦遇到访问重很低的网站上有大量抄袭、采集或者复制的内容，很可能就不再爬行。第三步：预处理搜索引擎将爬虫抓取回来的页面，进行各种步骤的预处理。',
	image : '../images/4.jpg',
	code : '../images/4.jpg',
	level : '中级',
	look_num : 1000
}
var el_container = $('.container')
function getResourceDetail(obj, res){
	var res_text = `<h3>${res.name}</h3>
			<p class="author_info"><span class="author glyphicon glyphicon-user">${res.uploader}</span><span class="time glyphicon glyphicon-time">2019-11-10</span></p>
			<h4>资源描述:</h4>
			<p class="content">${res.descn}</p>
			<hr>
			<div class="download">
				<p><span class="download_image glyphicon glyphicon-arrow-down">
					<a href="${res.image}" download="${res.image}">运行效果图</a></span>
				</p>
				<p><span class="download_code glyphicon glyphicon-arrow-down">
					<a href="${res.code}" download="${res.code}">源代码</a></span>
				</p>
			</div>`
	obj.html(res_text)
}
function res_detail_callback(xhr){
	var res = xhr.responseText
	res = rextojson(res)
	res = JSON.parse(res)
	if(res.status === 200){
		getResourceDetail(el_container, res.data)
		var main = $(window.parent.document).find("#resourceDetail");
		var thisheight = $(document).height();
		main.height(thisheight);
	} else {
		alert(res.msg)
	}
}
$(function(){
	var n = location.search.substring(1)
	ajax('get', '/resource/getResource',{
		resourceId : n
	}, res_detail_callback)
	var main = $(window.parent.document).find("#resourceDetail");
	var thisheight = $(document).height();
	main.height(thisheight);
})
