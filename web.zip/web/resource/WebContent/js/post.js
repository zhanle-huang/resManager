var res_post =  {   //假数据，帖子
				postId : 1,
				title : '路见不平一脚踹',
				name : 3117004268,
				content: '内阿萨大四很多撒谎大时代i按时爱上帝阿三华硕i安徽打开撒大苏打还是金卡和爱神的箭按实际宽度和啊吉萨客户端尽快暗黑世界肯定会就爱看圣诞节卡号就肯定会阿贾克斯阿瑟东阿瑟东阿瑟东',
				postDate : '2019-11-02',
				quality : '0'
			}
//假数据,评论
var comment = [
	{
		commentId : 1,
		postId : 1,
		studentId : 6654,
		content : 'sadsafa',
		time : '2019-01-01 12:12:00',
		children : ''
	},
	{
		commentId : 2,
		postId : 1,
		studentId : 3469,
		content : 'dasfaasd',
		time : '2019-01-01 12:25:00',
		children : ''
	}
]
var replys1 = [
	{
		commentId : 1,
		replyId : 1,
		studentId : 3114,
		content : 'sadasd//@311700:哈哈哈',
		time : '2019-02-022 12:12:12'
	},
	{
		commentId : 1,
		replyId : 2,
		studentId : 3134,
		content : 'asdsadasda//@311700:hehehe',
		time : '2019-02-022 12:12:16'
	}
]
var replys2 = [
	{
		commentId : 2,
		replyId : 3,
		studentId : 4654,
		content : 'sadasd//@311700:噜噜噜',
		time : '2019-02-022 12:12:12'
	},
	{
		commentId : 2,
		replyId : 4,
		studentId : 365,
		content : 'asdsadasda//@311700:咕咕咕',
		time : '2019-02-022 12:12:16'
	}
]
comment[0].children = replys1
comment[1].children = replys2
console.log(comment)
var reqPa = {
	postId : '',
	commentId : '',
	studentId : '',
	content : '',
	time : ''
}
var comment_ul = $('.comment ul');
var container = $('.container')
var p_head = $('.container .p_header')
var p_author = $('.container .author_info')
var content = $('.container .content')
reqPa.postId = $('.container .postId').text()

//评论id

function makePost(res_post){
	container[0].getElementsByTagName('h3')[0].innerText = res_post.title
	
	container[0].getElementsByClassName('postId')[0].innerText = res_post.postId
	p_author[0].getElementsByClassName('author')[0].innerText = res_post.name
	p_author[0].getElementsByClassName('time')[0].innerText = res_post.postDate
	content[0].innerText = res_post.content
}
function getComments(ul, res){
	var comments = ''
	var replys = ''
	for(var i = 0; i<res.length; i++){   //遍历评论
		comments += '<li>\
			<p><span class="glyphicon glyphicon-user"></span><span class="id">' + res[i].studentId + ':</span><span class="commentId">' + res[i].commentId + '</span></p>\
			<p class="c_content">' + res[i].content + '</p>\
			<p class="reply"><span class="time">' + res[i].time + '</span><span class="btn btn-reply" data-toggle="modal" data-target="#push_comment">回复</span></p>'
		for(var j = 0; j<res[i].children.length; j++){  //遍历子数据
			replys += '<li>\
				<p><span class="glyphicon glyphicon-user"></span><span class="id">' + res[i].children[j].studentId + ':</span><span class="commentId">' + res[i].children[j].commentId + '</span></p>\
				<p class="c_content">' + res[i].children[j].content + '</p>\
				<p class="reply"><span class="time">' + res[i].children[j].time + '</span><span class="btn btn-reply" data-toggle="modal" data-target="#push_comment">回复</span></p>\
			</li>'
		}
		if(replys != '' && replys != null){   //拼接子节点
			replys = '<ol>' + replys + '</ol></li>'
			comments += replys
			replys = ''
		}
		else{
			comments += '</li>'
		}
	}
	ul.html(comments)
}

//评论功能
var newComments = {}
comment_ul.on('click', function(e){
	if(!window.sessionStorage.getItem('studentId')){
		location.href = 'login.html'
	}
	if(window.sessionStorage.getItem('say') === '1'){
		alert('你已被禁言！')
		return 
	}
	newComments = {}
	if(e.target.classList.contains('btn-reply')){   //点击的是回复按钮
		var el_li = e.target.parentNode.parentNode
		reqPa.commentId = el_li.getElementsByClassName('commentId')[0].innerText  //拿到评论的id
		var contentInfo = el_li.getElementsByClassName('c_content')[0].innerText
		var replyId = el_li.getElementsByClassName('id')[0].innerText
		var n = contentInfo.indexOf('@')
		if(n>0){   //说明存在@符号
			contentInfo = contentInfo.substring(0,n-2)   //得到内容
		}
		contentInfo = '//@' + replyId + contentInfo
		newComments.commentId  = parseInt(reqPa.commentId)
		newComments.content = contentInfo
		 console.log(newComments)
	}
})

//发表回复,还差一个评论人的id
var push_comment = $('#push_comment')
push_comment.on('click', function(e){
	if(!window.sessionStorage.getItem('studentId')){
		location.href = 'login.html'
	}
	if(window.sessionStorage.getItem('say') === '1'){
		alert('你已被禁言！')
		return 
	}
	var newc = null
	var temp = newComments.content
	if(e.target.nodeName.toUpperCase() === 'SPAN'){
		newc = $('#new_comment')
		newComments.content = newc.val() + temp;
		newComments.time = getDate()
		newComments.studentId = window.sessionStorage.getItem('studentId')
		
		console.log(newComments)
		ajax('get', '/resource/doReply',newComments, callback)
		getData()
	}
	
	
	if(newc != null && newc.val() != ''){
		newc[0].value = "";
	}
})

function getData(){
	ajax('get', '/resource/getPost',reqPa, post_callback)
	ajax('get', '/resource/getComments',reqPa, comment_callback)
}
var new_c_text = $('.comment .news_comment textarea')
var push_new_c_btn = $('.comment .news_comment span')
new_c_text.on('focus', function(){
	push_new_c_btn[0].style.display = "inline-block";
})

//发表新评论
push_new_c_btn.on('click', function(){
	if(!window.sessionStorage.getItem('studentId')){
		location.href = 'login.html'
	}
	//新评论  
	reqPa.content = new_c_text.val()
	reqPa.studentId = window.sessionStorage.getItem('studentId')
	reqPa.time = getDate()
	console.log(reqPa)
	ajax('get', '/resource/doComment',reqPa, callback)
	getData()
	new_c_text.val('')
})
//回调
function post_callback(xhr){
	var res = xhr.responseText
	res = rextojson(res)
	res = JSON.parse(res)
	if(res.status === 200){
		makePost(res.data)
	} else {
		alert(res.msg)
	}
}
function comment_callback(xhr){
	var res = xhr.responseText
	console.log(res)
	res = rextojson(res)
	console.log(res)
	res = JSON.parse(res)
	console.log(res)
	if(res.status === 200){
		getComments(comment_ul, res.data)
		var main = $(window.parent.document).find("#managerIframe");
		var thisheight = $(document).height();
		main.height(thisheight);
	} else {
		alert(res.msg)
	}
}
function callback(xhr){
	var res = xhr.responseText
	res = rextojson(res) 
	res = JSON.parse(res)
	if(res.status === 200){
		alert(res.msg)
	} else {
		alert(res.msg)
	}
}
//调用
$(function(){
	reqPa.postId = location.search.substring(1)
	getData()
})





