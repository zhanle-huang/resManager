



//事件
//修改
$('#confirm').on('click', function(){
	var str = $('form').serialize()
	console.log(str)
	ajax('post', '/resource/changepwd', str, c_callback)
})
function c_callback(xhr){
	var res = xhr.responseText
	rextojson
	res = JSON.parse(res)
	console.log(res)
	if(res.status === 200){
		alert(res.msg)
		location.href = 'login.html'
	} else {
		alert(res.msg)
	}
}