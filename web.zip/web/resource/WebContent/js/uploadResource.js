//分类数据
var classify = [
	{
		categoryId : 1,
		name : '计算机类',
		descn : '这些资源可以让你走向世界的前沿'
	},
	{
		categoryId : 2,
		name : '贸易类',
		descn : '贸易是文化交流的重要手段，也是值得学习知识，非常有意义'
	}
]
var new_res = {}
var form = $('#new_resource')
var select_cate = $('#categoryId')
var el_image = $('#image')
var el_code = $("#code")
var upload_btn = $('.container span.btn')
function getCategory(obj, res){
	var res_select = '<option value="" selected>请选择</option>'
	for(var i = 0; i<res.length; i++){
		res_select += `<option value="${res[i].categoryId}">${res[i].name}</option>`
	}
	obj.html(res_select)
}

function checkForm(form){
	var el_inputs = form.getElementsByTagName('input')
	var selects = form.getElementsByTagName('select')
	var textareas = form.getElementsByTagName('textarea')
	for(var j = 0; j<selects.length; j++){
		var n = selects[j].selectedIndex
		if(selects[j].options[n].value === ''){
			alert("有项未选择，请填写完整信息！")
			return false
		}
	}
	for(var i = 0; i<el_inputs.length; i++){
		if(el_inputs[i].value === ''){
			alert("某一项未填写，请填写完整！")
			return false
		}
	}
	for(var k = 0; k<selects.length; k++){
		if(textareas[k].value === ''){
			alert("文本框未填写，请填写完整信息！")
			return false
		}
	}
	return true
}


$('#chioseImage').on('click', function(){
	el_image[0].click();
})
$('#chioseCode').on('click', function(){
	el_code[0].click();
})


//事件
//选择效果图
el_image.on('change', function(){
	$('#new_resource .image_res')[0].innerHTML = '<span class="glyphicon glyphicon-picture"></span>' + el_image[0].files[0].name + '<span class="del_img btn btn-danger">删除</span>'
	$('#chioseImage').css('display', 'none')
	$('#new_resource .del_img').on('click', function(){
		el_image[0].value = ''        //清空选择的值
		$('#new_resource .image_res')[0].innerHTML = ''
		$('#chioseImage').css('display', 'inline-block')
	})
})
//选择源代码
el_code.on('change', function(){
	$('#new_resource .code_res')[0].innerHTML = '<span class="glyphicon glyphicon-folder-open"></span>' + el_code[0].files[0].name + '<span class="del_code btn btn-danger">删除</span>'
	$('#chioseCode').css('display', 'none')
	$('#new_resource .del_code').on('click', function(){
		el_code[0].value = ''        //清空选择的值
		$('#new_resource .code_res')[0].innerHTML = ''
		$('#chioseCode').css('display', 'inline-block')
	})
})
$('#reset').on('click', function(){
	$('#new_resource')[0].reset();
	if($('#new_resource .del_code')[0] != undefined)
		$('#new_resource .del_code')[0].click()
	if($('#new_resource .del_img') != undefined)
		$('#new_resource .del_img')[0].click()
})
$(function(){
	var stu_id = window.sessionStorage.getItem('studentId')
	if(!stu_id){
		location.href = 'login.html'
	}
	new_res.uploader = stu_id
	console.log(stu_id)
	$('#uploader').val(new_res.uploader)
	$('#uploadMan').text(new_res.uploader)
	ajax('get', '/resource/getCategory', '', getCategory_callback)
})

//获取表单数据
$('#submit').on('click', function(){
	if(!checkForm(form[0])){
		return
	}
	alert($('form').serialize())
//	var select = $('#category')
//	var s_index = select[0].selectedIndex
//	new_res.categoryId = $('#category option:selected').val()
//	new_res.name = $('#name').val()
//	new_res.descn = $('textarea').val()
//	new_res.image = el_image[0].files[0]
//	new_res.code = el_code[0].files[0]
//	new_res.time = getDate()
//	console.log(new_res)
//	ajax('post', '/resource/uploadResource', new_res, upload_callback)
//	form[0].reset()
//	if($('#new_resource .del_code')[0] != undefined)
//		$('#new_resource .del_code')[0].click()
//	if($('#new_resource .del_img') != undefined)
//		$('#new_resource .del_img')[0].click()
})

//回调
function upload_callback(xhr){
	var res = xhr.responseText
	res = rextojson(res)
	console.log(res)
//	res = JSON.parse(res)
//	if(res.status === 200){
//		alert(res.msg)
//	} else {
//		alert(res.msg)
//	}
}
function getCategory_callback(xhr){
	var res = xhr.responseText
	res = rextojson(res)
	res = JSON.parse(res)
	if(res.status === 200){
		getCategory(select_cate, res.data)
	} else {
		alert(res.msg)
	}
}