//存放帖子信息对象
var post = {}
var post_title = $('#post_title')
var post_content = $('#post_content')
//已输入内容的地方
var flag = {
	title : 0,
	content : 0
}
var reqPa =  {
	title : '',
	name : '',
	content : '',
	postDate : ''
}
post_title.on('focus', function(){
	post_title.on('keyup', function(){
		reqPa.title = post_title.val()
		if(post.title === ''){
			flag.title = 0
		}
		else {
			flag.title = 1
		}
		
		if(flag.title === 1 && flag.content === 1){
			$('.container .panel form span.btn').attr('disabled',false)
		}
	})
})
post_content.on('focus', function(){
	post_content.on('keyup', function(){
		reqPa.content = post_content.val()
		if(post.content === ''){
			flag.content = 0
		}
		else {
			flag.content = 1
		}
		
		if(flag.title === 1 && flag.content === 1){
			console.log(post.content)
			$('.container .panel form span.btn').attr('disabled',false)
		}
	})
})
//发布事件
$('.container .panel form span.btn').on('click', function(){
	reqPa.name = window.sessionStorage.getItem('stuentId')
	reqPa.postDate = getDate()
	reqPa.name = window.sessionStorage.getItem('name')
	console.log(reqPa)
	ajax('post', '/resource/publishPost',reqPa, pub_callback)
})

//回调
function pub_callback(xhr){
	var res = xhr.responseText
	res = rextojson(res)
	res = JSON.parse(res)
	if(res.status === 200){
		alert(res.msg)
		location.href = 'getPosts.html'
	} else {
		alert(res.msg)
	}
}

