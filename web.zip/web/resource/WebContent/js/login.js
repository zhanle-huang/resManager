//


//方法
function lo_callback(xhr){
	var res = xhr.responseText
	if(StringtoJson2(res)){
		res = StringtoJson2(res)
	}
	res = JSON.parse(res)
	console.log(res)
	if(res.status === 200){
		window.sessionStorage.setItem('token',res.data.token)
		window.sessionStorage.setItem('studentId',res.data.id)
		window.sessionStorage.setItem('identity',res.data.identity)
		window.sessionStorage.setItem('name',res.data.name)
		window.sessionStorage.setItem('say',res.data.say)
		alert(res.msg)
		location.href = 'index.html'
	} else {
		alert(res.msg)
	}
	
}

//事件
//登录事件
$('#login').on('click', function(){
	var str = $('form').serialize()
	console.log(str)
	ajax('post', '/resource/login',  str, lo_callback)
})