var data_page = {   //data变量用于
	pageNum : '1',
	pageSize  : '6',
	total : ''
}
//搜索栏
var search_val = $('.panel form.search input')
var search_btn = $('.panel form.search span')
var el_tbody = $('.panel .table tbody')
var look_btn = $('.panel form.search tbody span')
search_btn.on('click', function(){
	if(search_val.val() === ''){   //查询请求
		getData()
	}
	else{
		var s = search_val.val()
		ajax('get', 'resource/getResources',{
			categoryId : s,
			pageSize : page_data.pageSize,
			pageNum : page_data.currentPage, 
	}, res_callback)
	}
	search_val.val('')
})
function getResource(obj, res){
	var res_td = ''
	for(var i = 0; i<res.length; i++){
		res_td += '<tr>\
				<td class="sourceId" style="display: none;">' + res[i].resourceId + '</td>\
		        <td>' + res[i].name + '</td>\
				<td>' + res[i].level + '</td>\
		        <td>' + res[i].uploader + '</td>\
				<td>' + res[i].time + '</td>\
				<td>' + res[i].look_num + '</td>\
				<td><span class="btn btn-danger btn-xs">查看</span></td>\
				</tr>'
	}
	obj.html(res_td)
}
function getData(){
	var id = location.search.substring(1)
	console.log(id)
	ajax('get', '/resource/getResources',{
		categoryId : id,
		pageSize : data_page.pageSize,
		pageNum : data_page.pageNum, 
	}, res_callback)
}
function res_callback(xhr){
	var res = xhr.responseText
	res = rextojson(res)
	res = JSON.parse(res)
	if(res.status === 200){
		data_page.total = res.total
		console.log(data_page)
		startPage(data_page, page_callback)
		getResource(el_tbody, res.data)
		//showPage()
		var main = $(window.parent.document).find("#resourceDetail");
		var thisheight = $(document).height();
		main.height(thisheight);
	} else {
		alert(res.msg)
	}
}
//查看指定的资源详情
el_tbody.on('click', function(e){
	if(e.target.nodeName.toUpperCase() === 'SPAN'){
		var el_tr = e.target.parentNode.parentNode
		var s = el_tr.getElementsByClassName('sourceId')[0].innerText
		location.href = 'resourceDetail.html?' + s
		console.log(s)
	}
})

$(function(){
	getData()
})
function page_callback(){
	getData()
}
