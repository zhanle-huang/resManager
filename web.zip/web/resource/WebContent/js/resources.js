//分类渲染
var classify = [
	{
		categoryId : 1,
		name : '计算机类',
		descn : '这些资源可以让你走向世界的前沿'
	},
	{
		categoryId : 2,
		name : '贸易类',
		descn : '贸易是文化交流的重要手段，也是值得学习知识，非常有意义'
	}
]
var el_nav_ul = $('.container ul.nav')

//方法
function getVlassifyNav(obj, res){
	var res_lis = ''
	for(var i = 0; i<res.length; i++){
		res_lis += '<li><a href="getResource.html?' + res[i].categoryId + '">' + res[i].name + '</a></li>'
	}
	obj.html(res_lis)
}

//控制iframe高度

$(function(){
	ajax('get', '/resource/getCategory', '', getCategory_callback)
	$('iframe')[0].src = "getResource.html?1"
	var mainheight = $('#resourceDetail').contents().find("body").height();
	$('#resourceDetail').height(mainheight);
})
    
//注册链接的点击事件
el_nav_ul.on('click', function(e){
	if(e.target.nodeName.toUpperCase() === "A"){
		e.preventDefault()
		var src = e.target.href
		var as = el_nav_ul[0].getElementsByTagName('a')
		for(var i = 0; i<as.length; i++){
			if(as[i].classList.contains('active')){
				as[i].classList.remove('active')
			}
		}
		e.target.classList.add('active')
		$('iframe')[0].src = src 
		console.log(src)
		var mainheight = $('#resourceDetail').contents().find("body").height();
		$('#resourceDetail').height(mainheight);
		
	}
})
//控制页面也换
el_nav_ul.on('click', function(e){
	if(e.target.nodeName.toUpperCase() === "A"){
		var src = e.target.href	
		$('iframe')[0].src = src 
		var mainheight = $('#resourceDetail').contents().find("body").height()
		$('#resourceDetail').height(mainheight)
		e.preventDefault()
	}
})
//回调
function getCategory_callback(xhr){
	var res = xhr.responseText
	if(StringtoJson(res)){
		res = StringtoJson(res)
	}
	res = JSON.parse(res)
	console.log(res.data)
	if(res.status === 200){
		getVlassifyNav(el_nav_ul, res.data)
	} else {
		alert(res.msg)
	}
}
//调用

// setIframeHeight($('iframe')[0])