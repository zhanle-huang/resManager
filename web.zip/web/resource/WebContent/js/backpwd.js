

//

//

//事件
//确认事件
$('#confirm').on('click', function(){
	var str = $('form').serialize()
	console.log(str)
})