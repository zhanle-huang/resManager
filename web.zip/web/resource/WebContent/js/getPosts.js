//帖子数据
var data_page = {
		pageSize: '6',
		pageNum : '1',
		total : ''
}
var res_data = []
//左边帖子信息
var el_left_ul = $('.container .leftPost .panel ul')
var el_right_ul = $('.container .right_list .panel ul')
function getPost(e_ul, res, src){
	var res_lis = '';
	for(var i = 0; i<res.length; i++){ 
		res_lis += '<li class="list-group-item">\
			<div class="d_header"><img src="'+src+'" width="30" height="30"><h3>' + res[i].title + '</h3></div><span class="postId" style="display:none;">' + res[i].postId + '</span>\
			<p class="content">' + res[i].content + '</p>\
			<p class="belong_info"><span class="author"><span class="glyphicon glyphicon-user"></span>' + res[i].name + '</span>\
				<span class="info">\
					<span class="glyphicon glyphicon-heart-empty">2019</span>\
					<span class="glyphicon glyphicon-eye-open">2350</span>\
					<span class="glyphicon glyphicon-comment">1563</span>\
				</span>\
			</p>\
		</li>'
	}
	if(res_lis != '' && res_lis != null){
		e_ul.innerHTML = res_lis;
	}
}
//右边列表
function getList(el_ul, res){
	var res_list = ''
	for(var i = 0; i<res.length; i++){
		res_list += `<li>
						<h3>${res[i].title}</h3><span class="postId" style="display:none;">${res[i].postId}</span>
						<p class="author_info">作者:<span class="author">${res[i].name}</span></p>
					</li>`
	}
	if(res_list != '' && res_list != null){
		el_ul.innerHTML = res_list
	}
}
//初始化请求
function getData(){
	ajax('get', '/resource/getPosts',data_page, post_callbak)
	ajax('get', '/resource/getPosts',data_page, postRight_callbak)
}
//回调函数
//左边数据回调
function post_callbak(xhr){
	var res = xhr.responseText
	
	if(StringtoJson(res)){
		res = StringtoJson(res)
	}
	res = JSON.parse(res)
	console.log(res)
	res_data.push.apply(res_data,res.data)
	if(res.status === 200){
		getPost(el_left_ul[0], res_data, '../images/post.svg')
	} else {
		alert(res.msg)
	}
}
//右边
function postRight_callbak(xhr){
	var res = xhr.responseText
	if(StringtoJson(res)){
		res = StringtoJson(res)
	}
	res = JSON.parse(res)
	console.log(res)
	if(res.status === 200){
		getList(el_right_ul[0], res.data)
	} else {
		alert(res.msg)
	}
}


//事件
$('.container .panel .panel-body ul').on('click', function(e){
	
	if(e.target.nodeName.toUpperCase() === 'H3'){	
		var el_li = e.target.parentNode.parentNode			
		var id = el_li.getElementsByClassName('postId')[0].innerText  //得到被点击的帖子id
		location.href = 'post.html?' + id
	}
})
$(function(){
	getData()
})
//滚动事件
document.onscroll = function(){
	var s = document.documentElement.scrollTop || document.body.scrollTop
	var body_h = window.getComputedStyle(document.getElementsByTagName('body')[0], null)['height']
	console.log(s,(parseFloat(body_h) - 700))
	if(s>= (parseFloat(body_h) - 700)) {
		console.log('滚动到啦', s, body_h)
		data_page.pageNum = data_page.pageNum - 0 + 1 +''
		ajax('get', '/resource/getPosts',data_page, post_callbak)
	}
}

//调用

