var page_data = {}  //此数据用来和指定的数据联动
var page = $('#page')
//方法
function makePage(res){
	if(Math.ceil(res.total/res.pageSize)>=5){
		var str_li = ''
		for(var i = 0; i< 5; i++){
			console.log(page_data.pageNum)
			if(i+1+'' === res.pageNum){
				str_li += `<li class="active">${i+1}</li>`
			} else {
				str_li += `<li>${i+1}</li>`
			}
		}
		$('#page ul').html(str_li)
	}
	else {
		var str_li = ''
		for(var i = 0; i< Math.ceil(res.total/res.pageSize); i++){
			
			if(i+1+'' === res.pageNum){
				str_li += `<li class="active">${i+1}</li>`
			} else {
				str_li += `<li>${i+1}</li>`
			}
		}
		$('#page ul').html(str_li)
	}
	lis = $('#page ul li')
	showOrHide(res)
}
function showOrHide(res){
	if(parseInt(res.pageNum) <= 1){
		
		$('#page .prepage').css('display', 'none')
		$('#page .nextpage').css('display', 'block')
		console.log("ss")
	} else if(parseInt(res.pageNum) >= (Math.ceil(res.total/res.pageSize) )) {
		$('#page .nextpage').css('display', 'none')
		$('#page .prepage').css('display', 'block')
	} else {
		$('#page .nextpage').css('display', 'block')
		$('#page .prepage').css('display', 'block')
	}
}
function ActiveLi(){
	lis.each(function(index){
		if(this.classList.contains('active')){
			this.classList.remove('active')
		}
		if(this.innerText === page_data.pageNum) {
			this.classList.add('active')
		}
	})
}
//页码变化Math.ceil(data.total/page_data.pageSize)
function pageChange(obj, data){
	var t = Math.ceil(data.total/data.pageSize)
	if(Math.ceil(data.total/data.pageSize)<=5){
	} else {  //五页以上就需要页码变化
		obj.each(function(index){
			if(parseInt(data.pageNum)<=3){  //选择的是1-3
				lis.each(function(index){
					this.innerText = index+1+''
				})
			} else if(parseInt(data.pageNum)>=t-2){  //后三页
				lis.each(function(index){
					this.innerText = t-4+index+''
				})
			} else {
				lis.each(function(index){  //其他情况，保持被选中的在中间
					this.innerText = parseInt(data.pageNum)-2+index+''
				})
			}
		})
	}
	showOrHide(data)  //隐藏和显示上一页下一页
	page_callback()  //页码改变运行回调
	ActiveLi()
}
//事件
//上一页
$('#page .prepage').on('click', function(){
	page_data.pageNum = parseInt(page_data.pageNum) - 1 + ""
	pageChange(lis, page_data)
})
//下一页
$('#page .nextpage').on('click', function(){
	page_data.pageNum = parseInt(page_data.pageNum) + 1 + ""
	pageChange(lis, page_data)
})
//页事件
$('#page ul').on('click', function(e){
	if(e.target.nodeName.toUpperCase() === 'LI'){
		var this_page = e.target.innerText
		if(this_page === page_data.pageNum)
			return false
		page_data.pageNum = this_page
		pageChange(lis, page_data)
		ActiveLi()
		console.log(page_data.pageNum)
	}
})
//page的select事件
$('select').on('change', function(e){
	var n = e.target.selectedIndex
	page_data.pageSize = e.target.options[n].value
	console.log(page_data)
})


//调用这个开始来表示启动分页组件，初设回调,每一次页码使用都会调用回调函数
function startPage(data, callback){
	page_data = data
	page_callback = callback
	makePage(page_data)
}
//需要改变回调函数的时候调用
function changeCallbackFunc(callback){
	page_callback = callback
}
                                                                                                                                                                                                                                                                                                                                                        