package resource;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;

import dao.ReturnData;
import dao.updateUserInfoC;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class updateUserInfo
 */
@WebServlet("/updateUserInfo")
public class updateUserInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updateUserInfo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("utf-8"); 
		response.setContentType("text/html; charset=UTF-8");
		updateUserInfoC u = new updateUserInfoC();
		ReturnData r =  new ReturnData();
		JSONObject j = new JSONObject();
		int test = 0;
		PrintWriter out = response.getWriter();
		u.setId(Integer.parseInt(request.getParameter("id")));
		String name = request.getParameter("name");
		String phone = request.getParameter("phone");
		String iden= request.getParameter("identity");
		String s = request.getParameter("say");
		String token = request.getParameter("token");
		if(name != null) {
			test = u.changeName(name);
		}
		if(phone != null) {
			test = u.changePhone(phone);
		}
		if(iden != null) {
			int identity  = Integer.parseInt(iden);
			test = u.changeIdentity(identity);
		}
		if(s != null) {
			int say = Integer.parseInt(s);
			test = u.changeSay(say);
		}
		if(token != null) {
			test = u.changeToken(token);
		}
		if(test != 0) {
			r.setStatus(200);
			r.setMsg("修改成功！");
		}else {
			r.setStatus(201);
			r.setMsg("修改失败！");
		}
		r.setData(null);
		j = JSONObject.fromObject(r);
		String d = "" + j;
		String d1 = StringEscapeUtils.unescapeJava(d);
		out.println(d1);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
