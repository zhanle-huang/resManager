package resource;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;

import dao.Total;
import dao.getRecommentResourceC;
import dao.getRecommentResourceC1;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class getRecommentResource
 */
@WebServlet("/getRecommentResource")
public class getRecommentResource extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getRecommentResource() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("utf-8"); 
		response.setContentType("text/html; charset=UTF-8");
		getRecommentResourceC1 g1 = new getRecommentResourceC1();
		getRecommentResourceC g = new getRecommentResourceC();
		Total r =  new Total();
		JSONObject j = new JSONObject();
		g1.setPageSize(Integer.parseInt(request.getParameter("pageSize")));
		g1.setPageNum(Integer.parseInt(request.getParameter("pageNum")));
		int s = g1.getPageSize();
		int n = g1.getPageNum();
		PrintWriter out = response.getWriter();
		String data = "";
		ResultSet i = g.get(n,s);
		ResultSet i1 = g.countAll();
		int count = 0;
		try {
			while(i1.next()) {
				count = i1.getInt(1);
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			while(i.next()) {
				g.setResourceId(i.getInt(1));
				g.setUploader(i.getInt(2));
				g.setName(i.getString(3));
				j = JSONObject.fromObject(g);
				if(data.equals("")) {
					data = data + j;
				}
				else {
					data =data + "," +j;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			r.setData(null);
			r.setMsg("推荐失败！");
			r.setStatus(201);
			r.setTotal(0);
			j = JSONObject.fromObject(r);
			String w = "" + j;
			String w1 = StringEscapeUtils.unescapeJava(w);
			out.println(w1);
			e.printStackTrace();
		}
		data = "[" + data + "]";
		r.setData(data);
		r.setMsg("推荐成功！");
		r.setStatus(200);
		r.setTotal(count);
		j = JSONObject.fromObject(r);
		String d = "" + j;
		String d1 = StringEscapeUtils.unescapeJava(d);
		System.out.println(d1);
		out.println(d1);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
