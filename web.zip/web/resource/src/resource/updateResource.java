package resource;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;

import dao.ReturnData;
import dao.updateResourceC;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class updateResource
 */
@WebServlet("/updateResource")
public class updateResource extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updateResource() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("utf-8"); 
		response.setContentType("text/html; charset=UTF-8");
		updateResourceC u = new updateResourceC();
		ReturnData r =  new ReturnData();
		JSONObject j = new JSONObject();
		int test = 0;
		PrintWriter out = response.getWriter();
		u.setResourceId(Integer.parseInt(request.getParameter("resourceId")));
		u.setCategoryId(Integer.parseInt(request.getParameter("categoryId")));
		test = u.change();
		if(test != 0) {
			r.setStatus(200);
			r.setMsg("修改成功！");
		}else {
			r.setStatus(201);
			r.setMsg("修改失败！");
		}
		r.setData(null);
		j = JSONObject.fromObject(r);
		String d = "" + j;
		String d1 = StringEscapeUtils.unescapeJava(d);
		out.println(d1);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
