package resource;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.ProgressListener;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.StringEscapeUtils;

import dao.JdbcDao;
import dao.JdbcImlp;
import dao.ReturnData;
import dao.uploadResourceC;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class uploadResource
 */
@WebServlet("/uploadResource2")
public class uploadResource2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public uploadResource2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
//		String path = this.getServletContext().getRealPath("/file");
		String path = "C:\\Users\\di.li.da.la\\Desktop\\学习\\Web\\第6组+黄展乐\\resource\\WebContent\\upload";
		System.out.println(path);
		StringBuffer sb = new StringBuffer();
		String filename = null;
		String image = null;
		int i = 0;
        try {
            //1 创建DiskFileItemFactory工厂
            DiskFileItemFactory factory = new DiskFileItemFactory();
            ServletFileUpload upload = new ServletFileUpload(factory);
            List<FileItem> list = upload.parseRequest(request);//parseRequest(request);
            System.out.println("获取对象");
            for(FileItem item:list) {
                if (item.isFormField()) {
                    String value = item.getString("UTF-8");
                    sb.append(value);
                    sb.append("-");
                } else {
                	if(i == 0) {
                		filename = item.getName();
                		
                	}else if(i==1){
                		image = item.getName();
                	}
                	i++;
                    System.out.println("filename: "+filename);
                    System.out.println(filename);
                    File file = new File(path);
                    if(!file.exists()) {
                    	file.mkdirs();
                    }
                    InputStream inputStream = item.getInputStream();
                    String saveFilename  = makeFileName(filename);
                    //得到文件得保存目录
                    OutputStream os  =new FileOutputStream(file+File.separator+filename);
                    
                    //创建一个缓冲区
                    byte buffer[] = new byte[1024];
                    //判断输入流是否已经读完的标识
                    int len = 0;
                    while ((len=inputStream.read(buffer))>0)
                    {
                        os.write(buffer,0,len);
                    }
                    inputStream.close();
                    os.close();

                }
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        
        System.out.println(sb);
        String[] splits = sb.substring(0,sb.length()).split("-");
        int cid = Integer.parseInt(splits[0]);
        int uploader = Integer.parseInt(splits[3]);
//        Connection
        JdbcDao jdbc = new JdbcImlp();
        String sql = "insert into resource values(?,?,?,?,?,?,?,?,?,?)";
        Connection conn = jdbc.getConnection();
        PreparedStatement pst = null;
		try {
			pst = conn.prepareStatement(sql);
			pst.setInt(1, 0);
			pst.setInt(2, cid);
			pst.setInt(3,uploader);
			pst.setString(4, splits[1]);
			pst.setString(5, splits[2]);
			pst.setString(6, "..\\upload\\"+filename);
			pst.setString(7, "..\\upload\\"+image);
			pst.setString(8, "低级");
			pst.setInt(9, 0);
			String time = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date());
			pst.setString(10, time);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		jdbc.add(null,pst);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private String makeFileName(String filename)
    {
        //为防止文件覆盖的现象发生，要为上传文件产生一个唯一的文件名
        return UUID.randomUUID().toString()+"_"+filename;
    }

    /**
     * 为防止目录下面出现太多文件，要使用hash算法打算存存储
     * @param filename
     * @param savePath
     * @return
     */
    private String makePath(String filename,String savePath)
    {

        int hashcode = filename.hashCode();
        int dir1 = hashcode&0xf;//0--15
        /*int dir2 = (hashcode&0xf0)>>4;//0--15*/

        //构建新的保存目录
        String dir   = savePath+"\\"+dir1;
        //File可以代表文件也可以代表目录
        File file = new File(dir);
        if(!file.exists())
        {
            file.mkdirs();
            System.out.println("创建新目录成功！路径地址为："+dir);

        }
        return  dir;

    }
}
