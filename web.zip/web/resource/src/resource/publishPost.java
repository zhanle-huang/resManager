package resource;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;

import dao.ReturnData;
import dao.publishPostC;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class publishPost
 */
@WebServlet("/publishPost")
public class publishPost extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public publishPost() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("utf-8"); 
		response.setContentType("text/html; charset=UTF-8");
		publishPostC p = new publishPostC();
		ReturnData r =  new ReturnData();
		JSONObject j = new JSONObject();
		PrintWriter out = response.getWriter();
		p.setTitle(request.getParameter("title"));
		p.setName(request.getParameter("name"));
		p.setContent(request.getParameter("content"));
		p.setPostDate(request.getParameter("postDate"));
		boolean n = p.add();
		if(!n) {
			r.setData(null);
			r.setStatus(200);
			r.setMsg("发布成功！");
			j = JSONObject.fromObject(r);
			
		}else {
			r.setData(null);
			r.setStatus(201);
			r.setMsg("发布失败！");
			j = JSONObject.fromObject(r);
		}
		String d = "" + j;
		String d1 = StringEscapeUtils.unescapeJava(d);
		out.println(d1);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
