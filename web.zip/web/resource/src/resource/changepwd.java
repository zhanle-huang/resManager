package resource;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang.StringEscapeUtils;
import dao.ChangepwdC;
import dao.ReturnData;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class repwdServlet
 */
@WebServlet("/changepwd")
public class changepwd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public changepwd() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("utf-8"); 
		response.setContentType("text/html; charset=UTF-8");
		ChangepwdC c = new ChangepwdC();
		ReturnData r =  new ReturnData();
		JSONObject j = new JSONObject();
		c.setId(Integer.parseInt(request.getParameter("id")));
		c.setPassword(request.getParameter("password"));
		c.setNewpwd(request.getParameter("newpwd"));
		int n = c.change();
		PrintWriter out = response.getWriter();
		System.out.println(n);
		if(n >= 1) {
			r.setData(null);
			r.setStatus(200);
			r.setMsg("修改成功！");
			j = JSONObject.fromObject(r);
			
		}else {
			r.setData(null);
			r.setStatus(201);
			r.setMsg("修改失败！");
			j = JSONObject.fromObject(r);
		}
		String d = "" + j;
		String d1 = StringEscapeUtils.unescapeJava(d);
		out.println(d1);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
