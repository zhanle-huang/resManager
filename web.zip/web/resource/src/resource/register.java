package resource;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;

import dao.ReturnData;
import dao.createToken;
import dao.registerC;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class register
 */
@WebServlet("/register")
public class register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("utf-8"); 
		response.setContentType("text/html; charset=UTF-8");
		registerC a = new registerC();
		ReturnData r =  new ReturnData();
		JSONObject j = new JSONObject();
		PrintWriter out = response.getWriter();
		a.setId(Integer.parseInt(request.getParameter("id")));
		a.setPassword(request.getParameter("password"));
		a.setName(request.getParameter("name"));
		a.setPhone(request.getParameter("phone"));
		a.setIdentity(Integer.parseInt(request.getParameter("identity")));
		a.setSay(0);
		a.setToken(createToken.getToken());
		boolean n = a.add();
		if(!n) {
			r.setData(null);
			r.setStatus(200);
			r.setMsg("注册成功！");
			j = JSONObject.fromObject(r);
			
		}else {
			r.setData(null);
			r.setStatus(201);
			r.setMsg("注册失败！");
			j = JSONObject.fromObject(r);
		}
		String d = "" + j;
		String d1 = StringEscapeUtils.unescapeJava(d);
		out.println(d1);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
