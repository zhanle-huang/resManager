package resource;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;

import dao.ReturnData;
import dao.getResourceC;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class getResource
 */
@WebServlet("/getResource")
public class getResource extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getResource() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("utf-8"); 
		response.setContentType("text/html; charset=UTF-8");
		getResourceC g = new getResourceC();
		ReturnData r =  new ReturnData();
		JSONObject j = new JSONObject();
		g.setResourceId(Integer.parseInt(request.getParameter("resourceId")));
		ResultSet i = g.get();
		String data = "";
		PrintWriter out = response.getWriter();
		try {
			while(i.next()) {
				g.setUploader(i.getInt(2));
				g.setName(i.getString(3));
				g.setDescn(i.getString(4));
				g.setImage(i.getString(5));
				g.setCode(i.getString(6));
				g.setLevel(i.getString(7));
				g.setLook_num(i.getInt(8));
				g.setTime(i.getString(9));
				j = JSONObject.fromObject(g);
				data = data + j;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			r.setData(null);
			r.setMsg("获取失败！");
			r.setStatus(201);
			j = JSONObject.fromObject(r);
			String w = "" + j;
			String w1 = StringEscapeUtils.unescapeJava(w);
			out.println(w1);
			e.printStackTrace();
		}
		r.setData(data);
		r.setMsg("获取成功！");
		r.setStatus(200);
		j = JSONObject.fromObject(r);
		String d = "" + j;
		String d1 = StringEscapeUtils.unescapeJava(d);
		out.println(d1);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
