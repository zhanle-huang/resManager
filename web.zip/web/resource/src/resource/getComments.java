package resource;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;

import dao.ReturnData;
import dao.getCommentsC;
import dao.getReplysC;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class getCommentsC
 */
@WebServlet("/getComments")
public class getComments extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getComments() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("utf-8"); 
		response.setContentType("text/html; charset=UTF-8");
		getCommentsC g = new getCommentsC();
		getReplysC g1 = new getReplysC();
		ReturnData r =  new ReturnData();
		JSONObject j = new JSONObject();
		JSONObject j1 = new JSONObject();
		g.setPostId(Integer.parseInt(request.getParameter("postId")));
		ResultSet i = g.get();
		String data = "";
		PrintWriter out = response.getWriter();
		try {
			while(i.next()) {
				g.setCommentId(i.getInt(1));
				//获取二级回复
				g1.setCommentId(g.getCommentId());
				ResultSet i1 = g1.get();
				String data1 = "";
				try {
					while(i1.next()) {
						g1.setReplyId(i1.getInt(2));
						g1.setStudentId(i1.getInt(3));
						g1.setContent(i1.getString(4));
						g1.setTime(i1.getString(5));
						j1 = JSONObject.fromObject(g1);
						if(data1.equals("")) {
							data1 = data1 + j1;
						}
						else {
							data1 = data1 +"," +  j1;
						}
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				data1 = "[" + data1 + "]";
				//
				g.setPostId(i.getInt(2));
				g.setStudentId(i.getInt(3));
				g.setContent(i.getString(4));
				g.setTime(i.getString(5));
				g.setChildren(data1);
				j = JSONObject.fromObject(g);
				if(data.equals("")) {
					String t = data + j;
					data = StringEscapeUtils.unescapeJava(t);
				}
				else {
					String t =  data +"," +j;
					data = StringEscapeUtils.unescapeJava(t);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			r.setData(null);
			r.setMsg("获取失败！");
			r.setStatus(201);
			j = JSONObject.fromObject(r);
			String w = "" + j;
			String w1 = StringEscapeUtils.unescapeJava(w);
			out.println(w1);
			e.printStackTrace();
		}
		data = "[" + data + "]";
		r.setData(data);
		r.setMsg("获取成功！");
		r.setStatus(200);
		j = JSONObject.fromObject(r);
		String d = "" + j;
		String d1 = StringEscapeUtils.unescapeJava(d);
		out.println(d1);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
