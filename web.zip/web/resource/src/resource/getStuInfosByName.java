package resource;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;

import dao.Total;
import dao.getStuInfosByNameC;
import dao.getStuInfosByNameC1;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class getStuInfosByName
 */
@WebServlet("/getStuInfosByName")
public class getStuInfosByName extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getStuInfosByName() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("utf-8"); 
		response.setContentType("text/html; charset=UTF-8");
		getStuInfosByNameC1 g1 = new getStuInfosByNameC1();
		getStuInfosByNameC g = new getStuInfosByNameC();
		Total r =  new Total();
		JSONObject j = new JSONObject();
		g1.setName(request.getParameter("name"));
		g1.setPageSize(Integer.parseInt(request.getParameter("pageSize")));
		g1.setPageNum(Integer.parseInt(request.getParameter("pageNum")));
		int s = g1.getPageSize();
		int n = g1.getPageNum();
		String m = g1.getName();
		ResultSet i = g.getAll(m,n,s);
		ResultSet i1 = g.count();
		PrintWriter out = response.getWriter();
		String data = "";
		int count = 0;
		try {
			while(i1.next()) {
				count = i1.getInt(1);
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			while(i.next()) {
				g.setStudentId(i.getInt(1));
				g.setClassId(i.getInt(2));
				g.setMajorOrEle(i.getInt(3));
				g.setTeacher(i.getString(4));
				g.setSelfDescn(i.getString(5));
				j = JSONObject.fromObject(g);
				if(data.equals("")) {
					data = data + j;
				}
				else {
					data =  data +"," + j;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			r.setData(null);
			r.setMsg("查询失败！");
			r.setStatus(201);
			r.setTotal(0);
			j = JSONObject.fromObject(r);
			String w = "" + j;
			String w1 = StringEscapeUtils.unescapeJava(w);
			out.println(w1);
			e.printStackTrace();
		}
		data = "[" + data + "]";
		r.setData(data);
		r.setMsg("查询成功！");
		r.setStatus(200);
		r.setTotal(count);
		j = JSONObject.fromObject(r);
		String d = "" + j;
		String d1 = StringEscapeUtils.unescapeJava(d);
		out.println(d1);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
