package resource;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;

import dao.ReturnData;
import dao.getPostC;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class getPost
 */
@WebServlet("/getPost")
public class getPost extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getPost() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("utf-8"); 
		response.setContentType("text/html; charset=UTF-8");
		getPostC g = new getPostC();
		ReturnData r =  new ReturnData();
		JSONObject j = new JSONObject();
		g.setPostId(Integer.parseInt(request.getParameter("postId")));
		ResultSet i = g.get();
		String data = "";
		PrintWriter out = response.getWriter();
		try {
			while(i.next()) {
				g.setTitle(i.getString(1));
				g.setName(i.getString(2));
				g.setContent(i.getString(3));
				g.setPostDate(i.getString(4));
				g.setQuality(i.getInt(5));
				j = JSONObject.fromObject(g);
				data = data + j;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			r.setData(null);
			r.setMsg("查询失败！");
			r.setStatus(201);
			j = JSONObject.fromObject(r);
			String w = "" + j;
			String w1 = StringEscapeUtils.unescapeJava(w);
			out.println(w1);
			e.printStackTrace();
		}
		r.setData(data);
		r.setMsg("查询成功！");
		r.setStatus(200);
		j = JSONObject.fromObject(r);
		String d = "" + j;
		String d1 = StringEscapeUtils.unescapeJava(d);
		out.println(d1);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
