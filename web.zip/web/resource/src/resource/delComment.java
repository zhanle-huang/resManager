package resource;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;

import dao.ReturnData;
import dao.delCommentC;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class delComment
 */
@WebServlet("/delComment")
public class delComment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public delComment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("utf-8"); 
		response.setContentType("text/html; charset=UTF-8");
		delCommentC d = new delCommentC();
		ReturnData r =  new ReturnData();
		JSONObject j = new JSONObject();
		PrintWriter out = response.getWriter();
		d.setCommentId(Integer.parseInt(request.getParameter("commentId")));
		d.setPostId(Integer.parseInt(request.getParameter("postId")));
		boolean n = d.delete();
		if(!n) {
			r.setData(null);
			r.setStatus(200);
			r.setMsg("删除成功！");
			j = JSONObject.fromObject(r);
			
		}else {
			r.setData(null);
			r.setStatus(201);
			r.setMsg("删除失败！");
			j = JSONObject.fromObject(r);
		}
		String d1 = "" + j;
		String d2 = StringEscapeUtils.unescapeJava(d1);
		out.println(d2);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
