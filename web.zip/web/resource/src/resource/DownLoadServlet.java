package resource;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;


@WebServlet("/DownLoadServlet")
public class DownLoadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//得到要下载的文件名称
        String fileName =  request.getParameter("filename");
        fileName = new String(fileName.getBytes("iso8859-1"),"utf-8");
        //上传文件都是保存在/web-inf/upload目录下的子目录中
        String fileSaveRootPath = this.getServletContext().getRealPath("/WEB-INF");
        //通过文件名找到文件所在的目录
        String path = findFileSavePathByFileName(fileName,fileSaveRootPath);
        //得到要下载的文件
        File file = new File(path+"\\"+fileName);
        if(!file.exists())
        {
        	request.setAttribute("message","您要下载的资源不存在");
        	request.getRequestDispatcher("/message.html").forward(request,response);
            return;
        }
        //处理文件名称
        String realName = fileName.substring(fileName.lastIndexOf("_")+1);
        //控制浏览器下载该文件
        response.setHeader("content-disposition","attachment;filename="+URLEncoder.encode(realName,"UTF-8"));
        //读取需要下载的文件 保存到文件输入流
        FileInputStream fileInputStream = new FileInputStream(path+"//"+fileName);
        //创建输出流
        OutputStream fileOutputStream = response.getOutputStream();
        //创建缓冲区
        byte []buffer =new byte[1024];
        int len =0;
        while ((len = fileInputStream.read(buffer))>0)
        {
            fileOutputStream.write(buffer,0,len);
        }
        fileInputStream.close();
        fileOutputStream.close();
    }
        public String findFileSavePathByFileName(String filename,String saveRootPath)
        {
            int hashcode = filename.hashCode();
            int dir1 = hashcode&0xf;
            String dir  = saveRootPath+"//"+dir1;
            File file = new File(dir);
            if(!file.exists())
            {
                file.mkdir();
            }
            return dir;
	}

}
