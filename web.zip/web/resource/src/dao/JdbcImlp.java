package dao;

import java.sql.*;

public class JdbcImlp implements JdbcDao{
	Connection con = null;
	Statement sqlObj;
	ResultSet rs = null;
	String uri = "jdbc:mysql://localhost:3306/resource?user=root&password=123456&useSSL=true";
	
	@Override
	public void setUri(String uri) {
		this.uri = uri;
	}
	
	@Override
	public String getUri() {
		return this.uri;
	}
	public JdbcImlp() {
		init();
	}
	
	@Override
	public void init() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(Exception e) {
			System.out.println("加载驱动失败！");
			return;
		}
		System.out.println("加载成功！");
	}
	
	@Override
	public Connection getConnection() {
		try {
			con = DriverManager.getConnection(this.uri,"test","123456");
		}
		catch(SQLException e) {
			System.out.println("连接失败！");
		}
		try {
			sqlObj = con.createStatement();
		}
		catch(SQLException e) {
			System.out.println(e);
		}
		return con;
	}
	
	@Override
	public boolean add(String sql, PreparedStatement sql1) {
		getConnection();
		if(sql1 != null) {
			try {
				return sql1.execute();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("插入异常");
				e.printStackTrace();
				
			}
		}else {
			if(con == null) {
				return false;
			}
			try {
				boolean ok = sqlObj.execute(sql);
				return ok;
			}
			catch(SQLException e) {
				System.out.println(e);
			}
		}
		
		return false;
		
	}
	
	@Override
	public boolean delete(String sql) {
		getConnection();
		if(con == null) {
			return true;
		}
		try {
			boolean ok = sqlObj.execute(sql);
			System.out.println(ok);
			return ok;
		}
		catch(SQLException e) {
			System.out.println(e);
		}
		
		return true;
	}
	
	@Override
	public int update(String sql, PreparedStatement sql1) {
		getConnection();
		if(sql1 != null) {
			try {
				return  sql1.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(con == null) {
			return 0;
		}
		try {
			int ok = sqlObj.executeUpdate(sql);
			return ok;
		}
		catch(SQLException e) {
			System.out.println(e);
		}
		
		return 0;
	}
	
	@SuppressWarnings("null")
	@Override
	public ResultSet select(String sql) {
		getConnection();
		if(con == null) {
			System.out.println("出错");
			return rs;
		}
		try {
			rs = sqlObj.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return rs;
	}
	
	@Override
	public void close() {
		if(con != null) {
			try {
				con.close();
			}
			catch(SQLException e) {
				System.out.println(e);
			}
		}
		
	}
}
