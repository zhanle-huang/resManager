package dao;

public class deleteUserC {
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public boolean delete() {
		String sql = "delete from user where id ="+this.id;
		JdbcImlp jdbc = new JdbcImlp();
		boolean n = jdbc.delete(sql);
		return n;
	}
}
