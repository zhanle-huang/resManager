package dao;

public class updateResourceC {
	private int resourceId;
	private int categoryId;
	public int getResourceId() {
		return resourceId;
	}
	public void setResourceId(int resourceId) {
		this.resourceId = resourceId;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public int change() {
		String sql = "update resource set categoryId=" + this.categoryId+ " where resourceId=" + this.resourceId;
		JdbcImlp jdbc = new JdbcImlp();
		int n = jdbc.update(sql, null);
		return n;
	}
}
