package dao;

import java.sql.ResultSet;

public class getPostC {
	private int postId;
	private String title;
	private String name;
	private String content;
	private String postDate;
	private int quality;
	public int getPostId() {
		return postId;
	}
	public void setPostId(int postId) {
		this.postId = postId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPostDate() {
		return postDate;
	}
	public void setPostDate(String postDate) {
		this.postDate = postDate;
	}
	public int getQuality() {
		return quality;
	}
	public void setQuality(int quality) {
		this.quality = quality;
	}
	public ResultSet get() {
		String sql = "select title,name,content,postDate,quality from posts where postId ="+this.postId;
		JdbcImlp jdbc = new JdbcImlp();
		ResultSet n = jdbc.select(sql);
		return n;
	}
}
