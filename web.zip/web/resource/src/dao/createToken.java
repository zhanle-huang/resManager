package dao;
import java.util.UUID;
public class createToken {
	public static String getToken() {
		String a = UUID.randomUUID().toString();
		String b = a.replaceAll("-", "").substring(0, 16);
		return b;
	}
}