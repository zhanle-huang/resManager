package dao;

import java.sql.ResultSet;

public class loginC {
	private int id;
	private String password;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public ResultSet get() {
		String sql = "select id,name,say,token,identity from user where id ="+this.id+" and password = \'"+this.password+"\'";
		System.out.println(sql);
		JdbcImlp jdbc = new JdbcImlp();
		ResultSet n = jdbc.select(sql);
		return n;
	}
}
