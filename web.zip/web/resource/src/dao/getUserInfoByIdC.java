package dao;

import java.sql.ResultSet;

public class getUserInfoByIdC {
	private int id;
	private String password;
	private String name;
	private String phone;
	private int identity;
	private int say;
	private String token;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getIdentity() {
		return identity;
	}
	public void setIdentity(int identity) {
		this.identity = identity;
	}
	public int getSay() {
		return say;
	}
	public void setSay(int say) {
		this.say = say;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public ResultSet get() {
		String sql = "select id,password,name,phone,identity,say,token from user where id = "+this.id;
		JdbcImlp jdbc = new JdbcImlp();
		ResultSet n = jdbc.select(sql);
		return n;
	}
}
