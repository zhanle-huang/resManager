package dao;

public class delPostC {
	private int postId;

	public int getPostId() {
		return postId;
	}

	public void setPostId(int postId) {
		this.postId = postId;
	}
	public boolean delete() {
		String sql = "delete from posts where postId ="+this.postId;
		JdbcImlp jdbc = new JdbcImlp();
		boolean n = jdbc.delete(sql);
		return n;
	}
}
