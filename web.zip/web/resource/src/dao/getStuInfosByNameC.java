package dao;

import java.sql.ResultSet;

public class getStuInfosByNameC {
	private int studentId;
	private int classId;
	private int majorOrEle;
	private String teacher;
	private String selfDescn;
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public int getMajorOrEle() {
		return majorOrEle;
	}
	public void setMajorOrEle(int majorOrEle) {
		this.majorOrEle = majorOrEle;
	}
	public String getTeacher() {
		return teacher;
	}
	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}
	public String getSelfDescn() {
		return selfDescn;
	}
	public void setSelfDescn(String selfDescn) {
		this.selfDescn = selfDescn;
	}
	public ResultSet getAll(String name,int pageNum,int pageSize) {
		String sql = "select studentId,classId,majorOrEle,teacher,selfDescn from students where studentId in (select id from user where name = \'"+name+"\' ) limit "+((pageNum-1)*pageSize)+","+pageSize;
		JdbcImlp jdbc = new JdbcImlp();
		ResultSet n = jdbc.select(sql);
		return n;
	}
	public ResultSet count() {
		String sql = "select count(*) from students";
		JdbcImlp jdbc = new JdbcImlp();
		ResultSet n = jdbc.select(sql);
		return n;
	}
}
