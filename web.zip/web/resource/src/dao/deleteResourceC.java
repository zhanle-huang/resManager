package dao;

public class deleteResourceC {
	private int resourceId;

	public int getResourceId() {
		return resourceId;
	}

	public void setResourceId(int resourceId) {
		this.resourceId = resourceId;
	}
	public boolean delete() {
		String sql = "delete from resource where resourceId ="+this.resourceId;
		JdbcImlp jdbc = new JdbcImlp();
		boolean n = jdbc.delete(sql);
		return n;
	}
}
