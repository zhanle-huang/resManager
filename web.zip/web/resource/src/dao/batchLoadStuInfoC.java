package dao;

public class batchLoadStuInfoC {
	private int studentId;
	private int classId;
	private int majorOrEle;
	private String teacher;
	private String selfDescn;
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public int getMajorOrEle() {
		return majorOrEle;
	}
	public void setMajorOrEle(int majorOrEle) {
		this.majorOrEle = majorOrEle;
	}
	public String getTeacher() {
		return teacher;
	}
	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}
	public String getSelfDescn() {
		return selfDescn;
	}
	public void setSelfDescn(String selfDescn) {
		this.selfDescn = selfDescn;
	}
	public boolean add() {
		String sql = "insert into students(studentId,classId,majorOrEle,teacher,selfDescn) values ("+this.studentId+","+this.classId+","+this.majorOrEle+",\'"+this.teacher+"\',\'"+this.selfDescn+"\')";
		JdbcImlp jdbc = new JdbcImlp();
		boolean n = jdbc.add(sql,null);
		return n;
	}
}
