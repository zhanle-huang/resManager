package dao;

public class updateUserInfoC {
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int changeName(String name) {
		String sql = "update user set name=\'" + name+ "\' where Id=" + this.id;
		JdbcImlp jdbc = new JdbcImlp();
		int n = jdbc.update(sql, null);
		return n;
	}
	public int changePhone(String phone) {
		String sql = "update user set phone=\'" + phone+ "\' where Id=" + this.id;
		JdbcImlp jdbc = new JdbcImlp();
		int n = jdbc.update(sql, null);
		return n;
	}
	public int changeIdentity(int identity) {
		String sql = "update user set identity=" + identity+ " where Id=" + this.id;
		JdbcImlp jdbc = new JdbcImlp();
		int n = jdbc.update(sql, null);
		return n;
	}
	public int changeSay(int say) {
		String sql = "update user set say=" + say+ " where Id=" + this.id ;
		JdbcImlp jdbc = new JdbcImlp();
		int n = jdbc.update(sql, null);
		return n;
	}
	public int changeToken(String token) {
		String sql = "update user set token=\'" + token+ "\' where Id=" + this.id;
		JdbcImlp jdbc = new JdbcImlp();
		int n = jdbc.update(sql, null);
		return n;
	}
}
