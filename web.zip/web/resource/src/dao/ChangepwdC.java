package dao;

public class ChangepwdC {
	private int id;
	private String password;
	private String newpwd;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNewpwd() {
		return newpwd;
	}
	public void setNewpwd(String newpwd) {
		this.newpwd = newpwd;
	}
	public int change() {
		String sql = "update user set password=\'" + this.newpwd + "\' where id=" + this.id + " and password=\'" + this.password + "\'";
		System.out.println(sql);
		JdbcImlp jdbc = new JdbcImlp();
		int n = jdbc.update(sql, null);
		return n;
	}
}
