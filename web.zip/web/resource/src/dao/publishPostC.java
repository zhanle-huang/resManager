package dao;

public class publishPostC {
	private String title;
	private String name;
	private String content;
	private String postDate;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPostDate() {
		return postDate;
	}
	public void setPostDate(String postDate) {
		this.postDate = postDate;
	}
	public boolean add() {
		String sql = "insert into posts(title,name,content,postDate) values (\'"+this.title+"\',\'"+this.name+"\',\'"+this.content+"\',\'"+this.postDate+"\')";
		JdbcImlp jdbc = new JdbcImlp();
		boolean n = jdbc.add(sql,null);
		return n;
	}
}
