package dao;

public class doCommentC {
	private int postId;
	private int studentId;
	private String content;
	private String time;
	public int getPostId() {
		return postId;
	}
	public void setPostId(int postId) {
		this.postId = postId;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public boolean add() {
		String sql = "insert into comments(postId,studentId,content,time) values ("+this.postId+","+this.studentId+",\'"+this.content+"\',\'"+this.time+"\')";
		JdbcImlp jdbc = new JdbcImlp();
		boolean n = jdbc.add(sql,null);
		return n;
	}
}
