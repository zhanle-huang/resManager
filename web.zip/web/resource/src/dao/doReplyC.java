package dao;

public class doReplyC {
	private int commentId;
	private int studentId;
	private String content;
	private String time;
	public int getCommentId() {
		return commentId;
	}
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public boolean add() {
		String sql = "insert into replys(commentId,studentId,content,time) values ("+this.commentId+","+this.studentId+",\'"+this.content+"\',\'"+this.time+"\')";
		JdbcImlp jdbc = new JdbcImlp();
		boolean n = jdbc.add(sql,null);
		return n;
	}
}
