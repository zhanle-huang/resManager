package dao;

public class changeLevelC {
	private int resourceId;
	private String level;
	public int getResourceId() {
		return resourceId;
	}
	public void setResourceId(int resourceId) {
		this.resourceId = resourceId;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public int change() {
		String sql = "update resource set level=\'" + this.level+ "\' where resourceId=" + this.resourceId ;
		JdbcImlp jdbc = new JdbcImlp();
		int n = jdbc.update(sql, null);
		return n;
	}
}
