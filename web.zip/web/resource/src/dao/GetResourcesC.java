package dao;

import java.sql.ResultSet;

public class GetResourcesC {
	private int resourceId;
	private int uploader;
	private String time;
	private int look_num;
	private String level;
	private String name;
	private String descn;
	public String getDescn() {
		return descn;
	}
	public void setDescn(String descn) {
		this.descn = descn;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getLook_num() {
		return look_num;
	}
	public void setLook_num(int look_num) {
		this.look_num = look_num;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}

	public int getResourceId() {
		return resourceId;
	}
	public void setResourceId(int resourceId) {
		this.resourceId = resourceId;
	}
	public int getUploader() {
		return uploader;
	}
	public void setUploader(int uploader) {
		this.uploader = uploader;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ResultSet get(int categoryId,int pageNum,int pageSize) {
		String sql = "select resourceId,uploader,name,time,look_num,level,descn from resource where categoryId ="+categoryId+" limit "+((pageNum-1)*pageSize)+","+pageSize;
		JdbcImlp jdbc = new JdbcImlp();
		ResultSet n = jdbc.select(sql);
		return n;
	}
	public ResultSet getAll(int pageNum,int pageSize) {
		String sql = "select resourceId,uploader,name,time,look_num,level,descn from resource limit "+((pageNum-1)*pageSize)+","+pageSize;
		JdbcImlp jdbc = new JdbcImlp();
		ResultSet n = jdbc.select(sql);
		return n;
	}
	public ResultSet countAll() {
		String sql = "select count(*) from resource";
		JdbcImlp jdbc = new JdbcImlp();
		ResultSet n = jdbc.select(sql);
		return n;
	}
	public ResultSet count(int categoryId) {
		String sql = "select count(*) from resource where categoryId ="+categoryId;
		JdbcImlp jdbc = new JdbcImlp();
		ResultSet n = jdbc.select(sql);
		return n;
	}
}
