package dao;

import java.sql.ResultSet;

public class getRecommentResourceC {
	private int resourceId;
	private int uploader;
	private String name;
	public int getResourceId() {
		return resourceId;
	}
	public void setResourceId(int resourceId) {
		this.resourceId = resourceId;
	}
	public int getUploader() {
		return uploader;
	}
	public void setUploader(int uploader) {
		this.uploader = uploader;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ResultSet get(int pageNum,int pageSize) {
		String sql = "select resourceId,uploader,name from resource order by look_num desc limit "+((pageNum-1)*pageSize)+","+pageSize;
		JdbcImlp jdbc = new JdbcImlp();
		ResultSet n = jdbc.select(sql);
		return n;
	}
	public ResultSet countAll() {
		String sql = "select count(*) from resource";
		JdbcImlp jdbc = new JdbcImlp();
		ResultSet n = jdbc.select(sql);
		return n;
	}
}
