package dao;

import java.sql.ResultSet;

public class getCommentsC {
	private int commentId;
	private int postId;
	private int studentId;
	private String content;
	private String time;
	private String children;
	public int getCommentId() {
		return commentId;
	}
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	public int getPostId() {
		return postId;
	}
	public void setPostId(int postId) {
		this.postId = postId;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getChildren() {
		return children;
	}
	public void setChildren(String children) {
		this.children = children;
	}
	public ResultSet get() {
		String sql = "select commentId,postId,studentId,content,time from comments where postId ="+this.postId;
		JdbcImlp jdbc = new JdbcImlp();
		ResultSet n = jdbc.select(sql);
		return n;
	}
}
