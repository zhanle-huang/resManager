package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public interface JdbcDao {
	public void init();
	public Connection getConnection();
	public boolean add(String sql, PreparedStatement sql1);
	public boolean delete(String sql);
	public int update(String sql, PreparedStatement sql1);
	public ResultSet select(String sql);
	public void close();
	public void setUri(String uri);
	public String getUri();
}
