package dao;

public class delCommentC {
	private int commentId;
	private int postId;
	public int getCommentId() {
		return commentId;
	}
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	public int getPostId() {
		return postId;
	}
	public void setPostId(int postId) {
		this.postId = postId;
	}
	public boolean delete() {
		String sql = "delete from comments where postId ="+this.postId+" and commentId = "+this.commentId;
		JdbcImlp jdbc = new JdbcImlp();
		boolean n = jdbc.delete(sql);
		return n;
	}
}
