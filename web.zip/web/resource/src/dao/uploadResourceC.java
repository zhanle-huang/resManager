package dao;

public class uploadResourceC {
	private int categoryId;
	private int uploader;
	private String level;
	private String name;
	private String descn;
	private String image;
	private String code;
	private String time;
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public int getUploader() {
		return uploader;
	}
	public void setUploader(int uploader) {
		this.uploader = uploader;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescn() {
		return descn;
	}
	public void setDescn(String descn) {
		this.descn = descn;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public boolean upload() {
		String sql = "insert into resource(categoryId,uploader,name,descn,image,code,level,time) values ("+this.categoryId+","+this.uploader+",\'"+this.name+"\',\'"+this.descn+"\',\'"+this.image+"\',\'"+this.code+"\',\'"+this.level+"\',"+this.time+")";
		System.out.println(sql);
		JdbcImlp jdbc = new JdbcImlp();
		boolean n = jdbc.add(sql,null);
		return n;
	}
}
