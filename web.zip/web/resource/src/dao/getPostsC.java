package dao;

import java.sql.ResultSet;

public class getPostsC {
	private int postId;
	private String title;
	private String name;
	private String content;
	private String postDate;
	public int getPostId() {
		return postId;
	}
	public void setPostId(int postId) {
		this.postId = postId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPostDate() {
		return postDate;
	}
	public void setPostDate(String postDate) {
		this.postDate = postDate;
	}
	public ResultSet getAll(int pageNum,int pageSize) {
		String sql = "select postId,title,name,content,postDate from posts order by postDate desc limit "+((pageNum-1)*pageSize)+", "+pageSize;
		JdbcImlp jdbc = new JdbcImlp();
		ResultSet n = jdbc.select(sql);
		return n;
	}
	public ResultSet count() {
		String sql = "select count(*) from posts";
		JdbcImlp jdbc = new JdbcImlp();
		ResultSet n = jdbc.select(sql);
		return n;
	}
}
