/*
Navicat MySQL Data Transfer

Source Server         : web
Source Server Version : 50539
Source Host           : localhost:3306
Source Database       : resource

Target Server Type    : MYSQL
Target Server Version : 50539
File Encoding         : 65001

Date: 2019-12-31 15:23:18
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for replys
-- ----------------------------
DROP TABLE IF EXISTS `replys`;
CREATE TABLE `replys` (
  `commentId` int(10) NOT NULL,
  `replyId` int(10) NOT NULL AUTO_INCREMENT,
  `studentId` int(10) DEFAULT NULL,
  `content` varchar(300) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`replyId`),
  KEY `commentId` (`commentId`),
  KEY `StudentId` (`studentId`),
  CONSTRAINT `replys_ibfk_1` FOREIGN KEY (`commentId`) REFERENCES `comments` (`commentId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `replys_ibfk_2` FOREIGN KEY (`StudentId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of replys
-- ----------------------------
INSERT INTO `replys` VALUES ('8', '12', '12345', '呵呵//@12345:哈哈', '2019-12-30 15:37:29');
