/*
Navicat MySQL Data Transfer

Source Server         : web
Source Server Version : 50539
Source Host           : localhost:3306
Source Database       : resource

Target Server Type    : MYSQL
Target Server Version : 50539
File Encoding         : 65001

Date: 2019-12-31 15:23:11
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for posts
-- ----------------------------
DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `postId` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(30) NOT NULL,
  `name` varchar(10) NOT NULL,
  `content` varchar(500) NOT NULL,
  `postDate` datetime NOT NULL,
  `quality` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`postId`),
  KEY `Name` (`name`),
  CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`name`) REFERENCES `user` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of posts
-- ----------------------------
INSERT INTO `posts` VALUES ('1', 'java web技术概述', '黄六', 'javaweb应用越来越广泛，已经成为Internet上最重要的技术之一，软件开发的的重要组成成分，HTTP及相关技术技术，使用工具eclipse开发环境的安装，还有介绍动态web项目的建立与部署', '2019-12-01 07:06:33', '\0');
INSERT INTO `posts` VALUES ('2', '初学JavaWeb开发，请远离各种框架，从Servlet开始', '黄六', 'Web框架是开发者在使用某种语言编写Web应用服务端是关于架构的最佳实践。很多Web框架是从实际的Web项目抽取出来的，仅和Web的请求和响应处理有关，形成一个基础，在开发别的应用项目的时候则可以从这个剥离出来的基础做起，让开发者更关注具体的业务问题，而不是Web的请求和响应的控制。', '2019-12-02 07:09:49', '\0');
INSERT INTO `posts` VALUES ('3', 'JavaTM Web Start 是一种部署解决方案', '黄六', 'JavaTM Web Start 是基于 Java 技术的应用程序的一种部署解决方案。它是连接计算机和 Internet 的便捷通道，允许用户在完全脱离 Web 的情况下运行和管理应用程序。Java Web Start 提供一次单击激活应用程序的简易方法，并保证始终运行应用程序的最新版本，从而可避免复杂的安装或升级过程。', '2019-12-03 07:11:15', '\0');
INSERT INTO `posts` VALUES ('4', ' javaweb 程序连接mysql数据库', '黄六', '在web程序中想要连接数据库。 首先在mysql中建立数据库。 create database 数据库名。 use 数据库名//使用这个数据库。 之后就是在数据库中建表，根据自己的程序需要建表。 要连接数据库最重要的就是要下载jar包，在网上都能免费下载。 下载下来一个压缩包，把里面的jar包加到工程的lib文件下。', '2019-12-04 07:12:35', '\0');
INSERT INTO `posts` VALUES ('5', 'Spring 框架——spring入门教程', '黄六', 'Spring是一个开源框架，Spring的核心是控制反转（IoC）和面向切面（AOP）。简单来说，Spring是一个分层的JavaSE/EE full-stack(一站式) 轻量级开源框架。\r\n轻量级：与EJB对比，依赖资源少，销毁的资源少。\r\n分层： 一站式，每一个层都提供的解决方案\r\nSpring是一个开源框架，Spring的核心是控制反转（IoC）和面向切面（AOP）。简单来说，Spring是一个分层的JavaSE/EE full-stack(一站式) 轻量级开源框架。\r\n轻量级：与EJB对比，依赖资源少，销毁的资源少。\r\n分层： 一站式，每一个层都提供的解决方案\r\n', '2019-12-05 07:15:17', '\0');
INSERT INTO `posts` VALUES ('6', 'java web前端（总结）前端要求', '黄六', 'Web前端开发技术主要包括三个要素：HTML、CSS和JavaScript!HTML甚至不是一门语言，仅仅是简单的标记语言!CSS只是无类型的样式修饰语言。当然可以勉强算作弱类型语言。Javascript的基础部分相对来说不难，入手还算快。', '2019-12-06 07:19:18', '\0');
INSERT INTO `posts` VALUES ('7', 'java web之bootstrap学习', '黄六', '我们在开发前端页面的时候，如果每一个按钮、样式、处理浏览器兼容性的代码都要自己从零开始去写，那就太浪费时间了。所以我们需要一个框架，帮我们实现一个页面的基础部分和解决一些繁琐的细节，只要在它的基础上进行个性化定制就可以了。\r\nBootstrap 就是这样一个简洁、直观、强悍的前端开发框架，只要学习并遵守它的标准，即使是没有学过网页设计的开发者，也能做出很专业、美观的页面，极大地提高了工作效率。像下面这个漂亮的网站就是基于 Bootstrap 来开发的。\r\n', '2019-12-06 10:20:46', '\0');
INSERT INTO `posts` VALUES ('8', 'java web怎么学好，有哪些要学的', '黄六', '第一步：基础学起，先学html，javascript，这个简单能让你快速上手，了解到缤纷的网页是怎么做出来的，能激起你的探索欲望。\r\n第二步：前提是你已经有了java基础，学习jsp，servlet，数据库。你就知道网页上那些动态数据是怎么来的，怎么产生，怎么保存，怎么从服务器传递到客户端等等。\r\n第三步：学习struts等等框架，框架可以帮你省很多很多事，也可以让你慢慢了解到设计模式等更进一步的知识。但不要过分依赖框架，学习的同时要探究框架的实现原理，再复杂的问题也是由很简单基础的问题积累而成的。\r\n', '2019-12-07 07:21:56', '\0');
INSERT INTO `posts` VALUES ('9', ' javaweb使用ajax实现页面跳转', '黄六', '在springMVC框架中,当controller层方法返回String类型的时候默认是进行页面跳转,这时候后台使用return时ajax接收到的并不是后台返回的某个字符串或状态码,而是整个html对象,这时可以在后台的方法上添加注解 @ResponseBody,就可以直接使用return返回想要返回的字符串而不进行页面跳转,而且ajax接收到的也是我们想要返回的字符串而不是整个html对象,然后再进行判断后用window.location.href进行页面跳转', '2019-12-08 07:22:35', '\0');
INSERT INTO `posts` VALUES ('10', 'Java Web Servlet 生命周期', '黄六', 'Servlet运行在Servlet容器中，其生命周期由容器来管理。Servlet的生命周期通过javax.servlet.Servlet接口中的init()、service()和destroy()方法来表示\r\nServlet的生命周期包含了下面4个阶段：\r\n1.加载和实例化\r\n2.初始化\r\n3.请求处理\r\n4.服务终止\r\n', '2019-12-08 09:23:36', '\0');
INSERT INTO `posts` VALUES ('11', ' java web-----DAO设计模式', '黄六', 'DAO设计模式用于 j2ee 的数据层访问，包括五部分，\r\n数据库连接类（包含数据库的连接与关闭操作的一个类），\r\nVO类（私有变量与数据库表格对应，接收数据库中表格各字段内容），\r\nDAO接口类（包含数据库的各项操作，增，删，改，查函数的定义），\r\nDAO实现类（具体实现DAO接口中定义的数据库操作函数），\r\nDAO工厂类（提供一个返回值为DAO接口类型的静态方法，获得DAO实现的实例）\r\n', '2019-12-08 10:24:09', '\0');
INSERT INTO `posts` VALUES ('12', 'javaweb 框架Hibernate配置和使用', '黄六', '首先先简单的讲一下我对这个框架的理解 ：\r\n我认为这个框架就是把数据库得每一条记录变成一个对象，存储在框架的内部 调用修改方法的时候修改的是框架内部的对象而不是数据库的对象，只有提交事务的时候才会修改数据库的东西，但是呢实际上框架里是不存储东西的，总的说呢这个框架就是帮助java开发的时候可以用面向对象的思想去操作数据库\r\n使用之前肯定要导包 导入下面图片required文件夹中的所有的包\r\n', '2019-12-09 07:24:55', '\0');
INSERT INTO `posts` VALUES ('13', 'JDBC访问数据库', '黄六', 'JDBC（Java DataBase  Connectivity）由Java编写的类和接口组成，可以为多种关系数据库提供统一的访问方式，从而实现用Java代码操作数据库\r\n\r\n开发JDBC程序，四个基本步骤\r\n\r\n1.导入驱动包，加载驱动类    \r\n\r\n2.与数据库建立连接\r\n', '2019-12-09 11:25:30', '\0');
INSERT INTO `posts` VALUES ('14', 'JavaWeb学习——表达式语言', '黄六', '一、EL简介\r\n    JSP2.0最重要的特性之一就是表达式语言（EL），JSP用户可以使用它来访问应用程序数据。受ECMAScript和XPath表达式语言的启发，EL也设计成可以轻易编写免脚本的JSP页面。即页面中不使用任何JSP声明、表达式或者scriptlets。\r\n \r\n二、EL语法\r\n    EL语法结构： ${ expression }\r\n    它也常用来连接两个表达式。对于一系列的表达式，他们的取值将是从左到右进行，计算结果的类型为String，并且连接在一起。例如：${ 1+2 }${ 2+3}的结果是35。\r\n', '2019-12-10 07:26:20', '\0');
INSERT INTO `posts` VALUES ('15', '如何自定义JSTL标签？', '黄六', '1、引入jstl依赖：2、创建Java类继承SimpleTagSupport：3、编写标签文件。', '2019-12-10 12:27:08', '\0');
INSERT INTO `posts` VALUES ('16', 'Servlet异步处理', '黄六', '在Servlet 3.0中，我们可以从HttpServletRequest对象中获得一个AsyncContext对象，该对象构成了异步处理的上下文，Request和Response对象都可从中获取。AsyncContext可以从当前线程传给另外的线程，并在新的线程中完成对请求的处理并返回结果给客户端，初始线程便可以还回给容器线程池以处理更多的请求。如此，通过将请求从一个线程传给另一个线程处理的过程便构成了Servlet 3.0中的异步处理。', '2019-12-11 07:28:33', '\0');
INSERT INTO `posts` VALUES ('17', 'Servlet中多线程并发问题', '黄六', '首先了解一下Servlet的多线程机制，Servlet体系结构是建立在Java多线程机制之上的。当某客户初次请求Servlet时，Servlet容器会根据其配置文件（web.xml）实例化Servlet类。当有其他新的客户请求该Servlet时，Servlet容器将不会再实例化这个Servlet类，而是开辟一个新的线程，所以出现了单实例多线程状态。', '2019-12-12 07:29:12', '\0');
INSERT INTO `posts` VALUES ('18', 'AJAX技术概述', '黄六', 'AJAX即“Asynchronous Javascript And XML”（异步JavaScript和XML），是指一种创建交互式网页应用的网页开发技术。\r\nAjax 的核心是 JavaScript 对象 XmlHttpRequest。该对象在 Internet Explorer 5 中首次引入，它是一种支持异步请求的技术。简而言之，XmlHttpRequest 使您可以使用 JavaScript 向服务器提出请求并处理响应，而不阻塞用户。\r\n', '2019-12-13 07:29:43', '\0');
INSERT INTO `posts` VALUES ('19', 'DOM和JavaScript的关系是什么？', '黄六', '人们一般使用JavaScript代码，通过 DOM 来访问文档和其中的元素。DOM 并不是一个编程语言，但如果没有DOM， JavaScript 语言也不会有任何网页，XML页面以及涉及到的元素的概念或模型。在文档中的每个元素— 包括整个文档，文档头部， 文档中的表格，表头，表格中的文本都是文档所属于的文档对象模型（DOM）的一部分，因此它们可以使用DOM和一个脚本语言如 JavaScript，来访问和处理。', '2019-12-14 07:31:06', '\0');
INSERT INTO `posts` VALUES ('20', 'Struts2框架 简单介绍', '黄六', 'Struts2框架是用来替代servlet和jsp  他的功能就是访问服务器的请求、\r\n\r\n2.Struts2框架的优点\r\n1. 接受参数（能自动封装）\r\n2. 参数的校验\r\n3. 可以控制页面的跳转\r\n4. 可以防止表单的数据重复提交\r\n5. 显示等待页面\r\n', '2019-12-14 13:31:51', '\0');
INSERT INTO `posts` VALUES ('21', 'Spring框架介绍及使用', '黄六', 'Spring是一个开源框架，Spring是于2003 年兴起的一个轻量级的Java 开发框架，由Rod Johnson 在其著作Expert One-On-One J2EE Development and Design中阐述的部分理念和原型衍生而来。它是为了解决企业应用开发的复杂性而创建的。框架的主要优势之一就是其分层架构，分层架构允许使用者选择使用哪一个组件，同时为 J2EE 应用程序开发提供集成的框架。Spring使用基本的JavaBean来完成以前只可能由EJB完成的事情。然而，Spring的用途不仅限于服务器端的开发。从简单性、可测试性和松耦合的角度而言，任何Java应用都可以从Spring中受益。Spring的核心是控制反转（IoC）和面向切面（AOP）。简单来说，Spring是一个分层的JavaSE/EE full-stack(一站式) 轻量级开源框架。', '2019-12-15 07:32:20', '\0');
INSERT INTO `posts` VALUES ('29', 'haha ', '黄展乐', 'Youweiasd ', '2019-12-30 15:43:10', '\0');
