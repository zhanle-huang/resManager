/*
Navicat MySQL Data Transfer

Source Server         : web
Source Server Version : 50539
Source Host           : localhost:3306
Source Database       : resource

Target Server Type    : MYSQL
Target Server Version : 50539
File Encoding         : 65001

Date: 2019-12-31 15:23:22
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for resource
-- ----------------------------
DROP TABLE IF EXISTS `resource`;
CREATE TABLE `resource` (
  `resourceId` int(10) NOT NULL AUTO_INCREMENT,
  `categoryId` int(10) DEFAULT NULL,
  `uploader` int(10) DEFAULT NULL,
  `name` varchar(80) DEFAULT NULL,
  `descn` varchar(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `code` varchar(150) NOT NULL,
  `level` varchar(20) NOT NULL,
  `look_num` int(10) NOT NULL,
  `time` varchar(50) NOT NULL,
  PRIMARY KEY (`resourceId`),
  KEY `categoryId` (`categoryId`),
  KEY `uploader` (`uploader`),
  CONSTRAINT `resource_ibfk_1` FOREIGN KEY (`categoryId`) REFERENCES `category` (`categoryId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `resource_ibfk_2` FOREIGN KEY (`uploader`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of resource
-- ----------------------------
INSERT INTO `resource` VALUES ('2', '3', '1222', 'python', 'Python是一种计算机程序设计语言。是一种面向对象的动态类型语言，最初被设计用于编写自动化脚本(shell)，随着版本的不断更新和语言新功能的添加，越来越多被用于独立的、大型项目的开发。', '..\\upload\\python.jpg', '..\\upload\\python.txt', '中级', '0', '2019-12-10 22:53:15');
INSERT INTO `resource` VALUES ('3', '3', '1222', '服务器资源', '静态资源：\n一般客户端发送请求到web服务器，web服务器从内存在取到相应的文件，返回给客户端，客户端解析并渲染显示出来\n动态资源：\n一般客户端请求的动态资源，先将请求交于web容器，web容器连接数据库，数据库处理数据之后，将内容交给web服务器，web服务器返回给客户端解析渲染处理。', '..\\upload\\服务器资源.jpg', '..\\upload\\服务器资源.txt', '中级', '0', '2019-11-25 22:53:20');
INSERT INTO `resource` VALUES ('4', '3', '1222', 'Tomcat', 'Tomcat 服务器是一个免费的开放源代码的Web 应用服务器，属于轻量级应用服务器，在中小型系统和并发访问用户不是很多的场合下被普遍使用，是开发和调试JSP 程序的首选。', '..\\upload\\Tomcat.jpg', '..\\upload\\Tomcat.txt', '中级', '0', '2019-11-26 22:53:34');
INSERT INTO `resource` VALUES ('6', '2', '1222', '面向对象技术', '面向对象技术强调在软件开发过程中面向客观世界或问题域中的事物，采用人类在认识客观世界的过程中普遍运用的思维方法，直观、自然地描述客观世界中的有关事物。面向对象技术的基本特征主要有抽象性、封装性、继承性和多态性。', '..\\upload\\面向对象技术.jpg', '..\\upload\\面向对象技术.txt', '初级', '0', '2019-11-28 22:53:42');
INSERT INTO `resource` VALUES ('7', '4', '1222', 'JSP 标准标签库（JSTL）', 'JSTL支持通用的、结构化的任务，比如迭代，条件判断，XML文档操作，国际化标签，SQL标签。 除了这些，它还提供了一个框架来使用集成JSTL的自定义标签。', '..\\upload\\JSP 标准标签库（JSTL）.jpg', '..\\upload\\JSP 标准标签库（JSTL）txt', '初级', '0', '2019-11-29 22:53:46');
INSERT INTO `resource` VALUES ('9', '1', '1222', 'Spring框架', 'Spring框架是一个开放源代码的J2EE应用程序框架，由Rod Johnson发起，是针对bean的生命周期进行管理的轻量级容器（lightweight container）。', '..\\upload\\Spring框架.jpg', '..\\upload\\Spring框架.txt', '初级', '0', '2019-12-01 22:53:54');
INSERT INTO `resource` VALUES ('10', '5', '1222', 'hibernate软件包', ' Hibernate对JDBC访问数据库的代码做了封装，大大简化了数据访问层繁琐的重复性代码。 \n  Hibernate是一个基于jdbc的主流持久化框架，是一个优秀的ORM实现，它很大程度的简化了dao层编码工作。', '..\\upload\\hibernate软件包.jpg', '..\\upload\\hibernate软件包.txt', '初级', '0', '2019-12-02 22:53:59');
INSERT INTO `resource` VALUES ('11', '5', '1222', 'Struts2标签库常用标签', '《背影》由三毛(中国)编写，语言为中文。\r\nStruts2作为一个优秀的MVC框架，也把重点放在了这两部分上。控制器主要由Action来提供支持，而视图则是由大量的标签来提供支持。。', '..\\upload\\Struts2标签库常用标签.jpg', '..\\upload\\Struts2标签库常用标签.txt', '高级', '0', '2019-12-03 22:54:04');
INSERT INTO `resource` VALUES ('12', '5', '1222', 'Eclipse', '《红高梁家族》由莫言(中国)编写，语言为中文。\r\nEclipse 是一个开放源代码的、基于Java的可扩展开发平台。就其本身而言，它只是一个框架和一组服务，用于通过插件组件构建开发环境。幸运的是，Eclipse 附带了一个标准的插件集，包括Java开发工具（Java Development Kit，JDK）。', '..\\upload\\Eclipse.jpg', '..\\upload\\Eclipse.txt', '高级', '0', '2019-12-04 22:54:08');
INSERT INTO `resource` VALUES ('13', '5', '1222', 'jQuery', '《儒林外史》由吴敬梓(中国)编写，语言为中文。\r\njQuery是一个快速、简洁的JavaScript框架，是继Prototype之后又一个优秀的JavaScript代码库（或JavaScript框架）。jQuery设计的宗旨是“write Less，Do More”，即倡导写更少的代码，做更多的事情。', '..\\upload\\jQuery.jpg', '..\\upload\\jQuery.txt', '高级', '0', '2019-12-05 22:54:12');
INSERT INTO `resource` VALUES ('14', '5', '1222', 'MyBatis', 'MyBatis 是一款优秀的持久层框架，它支持定制化 SQL、存储过程以及高级映射。MyBatis 避免了几乎所有的 JDBC 代码和手动设置参数以及获取结果集。　', '..\\upload\\MyBatis.jpg', '..\\upload\\MyBatis.txt', '高级', '0', '2019-12-06 22:54:16');
INSERT INTO `resource` VALUES ('19', '5', '1222', 'JSTL', 'JSTL（Java server pages standarded tag library，即JSP标准标签库）是由JCP（Java community Proces）所制定的标准规范，它主要提供给Java Web开发人员一个标准通用的标签库，并由Apache的Jakarta小组来维护', '..\\upload\\JSTL.jpg', '..\\upload\\JSTL.txt', '高级', '0', '2019-12-12 22:54:37');
INSERT INTO `resource` VALUES ('20', '5', '1222', 'Spring Boot', 'Spring Boot致力于在蓬勃发展的快速应用开发领域(rapid application development)成为领导者。', '..\\upload\\Spring Boot.jpg', '..\\upload\\Spring Boot.txt', '高级', '0', '2019-12-13 22:54:41');
INSERT INTO `resource` VALUES ('21', '5', '1222', 'MySQL数据库', 'MySQL是一种开放源代码的关系型数据库管理系统（RDBMS），使用最常用的数据库管理语言--结构化查询语言（SQL）进行数据库管理。', '..\\upload\\MySQL数据库.jpg', '..\\upload\\MySQL数据库.txt', '高级', '0', '2019-12-14 22:54:45');
INSERT INTO `resource` VALUES ('29', '1', '12345', '发的', '阿斯顿撒阿斯达', '..\\upload\\圣诞树.html', '..\\upload\\分页组件练习.zip', '低级', '0', '2019-12-30 03:39:10');
