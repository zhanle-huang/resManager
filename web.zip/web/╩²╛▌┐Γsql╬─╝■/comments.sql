/*
Navicat MySQL Data Transfer

Source Server         : web
Source Server Version : 50539
Source Host           : localhost:3306
Source Database       : resource

Target Server Type    : MYSQL
Target Server Version : 50539
File Encoding         : 65001

Date: 2019-12-31 15:23:04
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for comments
-- ----------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `commentId` int(10) NOT NULL AUTO_INCREMENT,
  `postId` int(10) NOT NULL,
  `studentId` int(10) NOT NULL,
  `content` varchar(300) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`commentId`),
  KEY `PostId` (`postId`),
  KEY `StudentId` (`studentId`),
  CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`PostId`) REFERENCES `posts` (`PostId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`StudentId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of comments
-- ----------------------------
INSERT INTO `comments` VALUES ('5', '27', '12345', '哈哈哈', '2019-12-17 09:36:46');
INSERT INTO `comments` VALUES ('6', '27', '12345', '哇', '2019-12-17 09:38:27');
INSERT INTO `comments` VALUES ('8', '17', '12345', '哈哈', '2019-12-30 15:37:17');
