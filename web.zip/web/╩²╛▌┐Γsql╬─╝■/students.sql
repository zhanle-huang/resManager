/*
Navicat MySQL Data Transfer

Source Server         : web
Source Server Version : 50539
Source Host           : localhost:3306
Source Database       : resource

Target Server Type    : MYSQL
Target Server Version : 50539
File Encoding         : 65001

Date: 2019-12-31 15:23:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for students
-- ----------------------------
DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `studentId` int(10) DEFAULT NULL,
  `classId` int(10) DEFAULT NULL,
  `majorOrEle` bit(1) DEFAULT NULL,
  `teacher` varchar(10) DEFAULT NULL,
  `selfDescn` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of students
-- ----------------------------
INSERT INTO `students` VALUES ('1222', '101', '', '老师', '很好很强大。');
INSERT INTO `students` VALUES ('124', '1243', '', '发顺丰', '阿发');
INSERT INTO `students` VALUES ('131', '1231', '', '阿达', '阿发');
INSERT INTO `students` VALUES ('123', '142', '', '4ad', '阿达');
INSERT INTO `students` VALUES ('14124', '170802', '\0', '黄展乐', '我很喜欢这个课程');
INSERT INTO `students` VALUES ('12312', '170802', '', '啦啦啦', '我也是哦');
INSERT INTO `students` VALUES ('1313', '12314', '\0', '阿大撒', '啊实打实');
INSERT INTO `students` VALUES ('1324', '51231', '', '撒打算', '阿斯达');
