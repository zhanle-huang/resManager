/*
Navicat MySQL Data Transfer

Source Server         : web
Source Server Version : 50539
Source Host           : localhost:3306
Source Database       : resource

Target Server Type    : MYSQL
Target Server Version : 50539
File Encoding         : 65001

Date: 2019-12-31 15:23:34
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `name` varchar(10) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `identity` int(1) NOT NULL,
  `say` bit(1) NOT NULL DEFAULT b'0',
  `token` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1222', '123456', '黄六', '13902518301', '0', '', '');
INSERT INTO `user` VALUES ('12345', 'qwert', '黄展乐', '123432131', '2', '\0', '471aac94e55446f1');
INSERT INTO `user` VALUES ('13424', '12345', '邝绍文', '13424963234', '1', '\0', '14d3baf826d949b7');
INSERT INTO `user` VALUES ('123456', '1234567', '黄撒', '13902518301', '0', '\0', '257dad40d8184302');
