/*
Navicat MySQL Data Transfer

Source Server         : web
Source Server Version : 50539
Source Host           : localhost:3306
Source Database       : resource

Target Server Type    : MYSQL
Target Server Version : 50539
File Encoding         : 65001

Date: 2019-12-31 15:22:54
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `categoryId` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) DEFAULT NULL,
  `descn` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`categoryId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES ('1', '界面设计', '关于界面设计的。');
INSERT INTO `category` VALUES ('2', '应用逻辑设计', '关于应用逻辑设计的。');
INSERT INTO `category` VALUES ('3', '数据库设计', '关于数据库设计的。');
INSERT INTO `category` VALUES ('4', '系统架构及部署', '序系统架构及部署的。');
INSERT INTO `category` VALUES ('5', '案例系统', '关于案例系统的。');
